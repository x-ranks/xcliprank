# twizou 投稿ページ説明・画像寸法 v1

対象は twizou.net の本番ソースです。個別ページで投稿本文が空の場合に、保存済みの投稿者名・投稿日・公開タグだけを使った説明を表示します。title と description にタグ情報を自然に含め、動画カード画像に幅・高さを指定します。投稿データの本文やタグを新規生成・書き換えません。

`apply-production.sh --check` は現在のソース・配布ファイルの SHA-256 と runtime を照合し、変更しません。`--apply` はステージで全テスト・型検査・ビルドを行い、既存の監視・収集ロックを確認してから runtime を切り替えます。切替後に個別ページ・トップ・サイトマップを確認し、失敗時は直前の runtime に戻します。既存 Cron と監視ラッパーは変更しません。

```bash
bash /home/rbxfxmfd/twizou-growth-v1-20261024-production/apply-production.sh --check
bash /home/rbxfxmfd/twizou-growth-v1-20261024-production/apply-production.sh --apply
```

成功表示: `TWIZOU_GROWTH_V1_DEPLOYMENT_COMPLETE`、`PREVIOUS_RUNTIME_BACKUP=...`、`NEW_BUILD_ID=...`。未知のソース版、監視・収集実行中、検証失敗は成功扱いにせず停止します。失敗時は staging の非公開ログを確認し、同じスクリプトをそのまま再実行しないでください。

2026-10-24時点のローカル検証: `test-public-pages.cjs`、`test-public-video-service.cjs`、TypeScript 型検査が成功。実本番ソースとの照合、本番ビルド、本番反映は未実施です。
