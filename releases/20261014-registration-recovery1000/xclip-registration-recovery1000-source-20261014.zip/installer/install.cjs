const fs=require('fs'),path=require('path'),crypto=require('crypto'),{createRequire}=require('module'),{execFileSync}=require('child_process');
const project=path.resolve(process.argv[2]||''),restore=process.argv[3]||'',payload=JSON.parse(fs.readFileSync(path.join(__dirname,'payload.json'),'utf8'));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
function target(rel){const p=path.resolve(project,rel);if(!p.startsWith(project+path.sep))throw Error('UNSAFE_PATH');for(let x=p;x!==project;x=path.dirname(x))if(fs.existsSync(x)&&fs.lstatSync(x).isSymbolicLink())throw Error('SYMLINK_REFUSED');return p;}
function put(rel,bytes){const p=target(rel);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,bytes);}
if(!fs.existsSync(target('package.json'))||fs.realpathSync(project)!==project)throw Error('PROJECT_LAYOUT_INVALID');
if(restore){
 if(payload.scope!=='local')throw Error('PRODUCTION_RESTORE_USES_RUNTIME_BACKUP');
 const base=target('.local-admin/registration-recovery-backups')+path.sep,backup=path.resolve(restore);
 if(!backup.startsWith(base)||fs.realpathSync(backup)!==backup)throw Error('BACKUP_PATH_REFUSED');
 const manifest=JSON.parse(fs.readFileSync(path.join(backup,'manifest.json'),'utf8'));
 if(manifest.version!==1||manifest.project!==project||manifest.release!==payload.release)throw Error('BACKUP_VERSION_MISMATCH');
 for(const row of manifest.files){if(!(row.path in payload.files)||!fs.existsSync(target(row.path))||sha(fs.readFileSync(target(row.path)))!==row.installedHash)throw Error('FILE_EDITED_AFTER_INSTALL: '+row.path);}
 const registry=target('.local-admin/fxtwitter-curated-v1/state.json');
 if(fs.existsSync(registry)){
  let state;try{state=JSON.parse(fs.readFileSync(registry,'utf8'));}catch{throw Error('RESTORE_STATE_REVIEW_REQUIRED; private state preserved');}
  if(!Array.isArray(state.authors)||state.authors.length>100||state.authors.some(a=>a.registration?.sessionId||a.registration?.patrolReady))
    throw Error('RESTORE_STATE_REVIEW_REQUIRED; new registration state requires compatible code; private state preserved');
 }
 for(const row of manifest.files){if(row.before===null)fs.unlinkSync(target(row.path));else put(row.path,Buffer.from(row.before,'base64'));}
 console.log('XCLIP_REGISTRATION_RECOVERY1000_LOCAL_RESTORED; DB/patrol/private state retained');process.exit(0);
}
if(payload.scope==='production'&&!fs.existsSync(target('.xclip-production-staging')))throw Error('ISOLATED_STAGING_REQUIRED');
const before=new Map(),mismatch=[];
for(const[rel,text]of Object.entries(payload.files)){
 if(sha(Buffer.from(text))!==payload.hashes[rel])throw Error('PAYLOAD_HASH_FAILED');
 const p=target(rel),old=fs.existsSync(p)?fs.readFileSync(p):null;
 if(!payload.acceptedBefore[rel].includes(sha(old??Buffer.alloc(0))))mismatch.push(rel+' '+sha(old??Buffer.alloc(0)));
 before.set(rel,old);
}
for(const[rel,hashes]of Object.entries(payload.guards||{}))if(!fs.existsSync(target(rel))||!hashes.includes(sha(fs.readFileSync(target(rel)))))mismatch.push(rel+' GUARD_MISMATCH');
if(mismatch.length)throw Error('UNKNOWN_SOURCE_VERSION; no application files changed\n'+mismatch.join('\n'));
const ts=createRequire(target('package.json'))('typescript');
for(const[rel,text]of Object.entries(payload.files))if(/\.tsx?$/.test(rel)){
 const sf=ts.createSourceFile(rel,text,ts.ScriptTarget.Latest,true,rel.endsWith('.tsx')?ts.ScriptKind.TSX:ts.ScriptKind.TS);
 if(sf.parseDiagnostics.length)throw Error('SYNTAX_CHECK_FAILED: '+rel);
}
if(payload.scope==='local'){
 const key=p=>process.platform==='win32'?path.resolve(p).toLowerCase():path.resolve(p);
 const overlay=new Map(Object.entries(payload.files).filter(([rel])=>/\.tsx?$/.test(rel)).map(([rel,text])=>[key(target(rel)),text]));
 const dirs=new Set();for(const file of overlay.keys())for(let dir=path.dirname(file);dir.startsWith(key(project));dir=path.dirname(dir)){dirs.add(dir);if(dir===key(project))break;}
 const cfg=ts.readConfigFile(target('tsconfig.json'),ts.sys.readFile);if(cfg.error)throw Error('TSCONFIG_READ_FAILED');
 const parsed=ts.parseJsonConfigFileContent(cfg.config,ts.sys,project);if(parsed.errors.length)throw Error('TSCONFIG_INVALID');
 const options={...parsed.options,noEmit:true,incremental:false},host=ts.createCompilerHost(options),oldRead=host.readFile,oldExists=host.fileExists,oldDir=host.directoryExists;
 host.readFile=f=>overlay.get(key(f))??oldRead(f);host.fileExists=f=>overlay.has(key(f))||oldExists(f);host.directoryExists=d=>dirs.has(key(d))||!!oldDir?.(d);
 host.getSourceFile=(f,lang)=>{const text=host.readFile(f);return text===undefined?undefined:ts.createSourceFile(f,text,lang,true);};
 const inputs=Object.keys(payload.files).filter(rel=>/\.tsx?$/.test(rel)).map(rel=>target(rel));
 inputs.push(createRequire(target('package.json')).resolve('styled-jsx/global.d.ts'));
 const program=ts.createProgram(inputs,options,host),diagnostics=ts.getPreEmitDiagnostics(program);
 if(diagnostics.length)throw Error(ts.formatDiagnosticsWithColorAndContext(diagnostics,{getCanonicalFileName:x=>x,getCurrentDirectory:()=>project,getNewLine:()=> '\n'}));
 const checkRel='.local-admin/registration-recovery-check-'+crypto.randomBytes(6).toString('hex'),check=target(checkRel);
 fs.mkdirSync(check,{recursive:true});
 try{
  fs.cpSync(target('lib'),path.join(check,'lib'),{recursive:true,filter:p=>!fs.lstatSync(p).isSymbolicLink()});
  const manager='app/api/curated-manager/route.ts';const managerTarget=path.join(check,manager);fs.mkdirSync(path.dirname(managerTarget),{recursive:true});fs.copyFileSync(target(manager),managerTarget);
  for(const[rel,text]of Object.entries(payload.files)){const f=path.join(check,rel);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,text);}
  for(const test of ['test-free-curated-timeline.cjs','test-fxtwitter-curated.cjs','test-free-curated-registration.cjs','test-free-curated-cursors.cjs','test-registration-recovery.cjs','test-registration-progress.cjs','test-curated-manager-local.cjs'])execFileSync(process.execPath,[path.join(check,'scripts',test)],{cwd:check,stdio:'inherit',env:{...process.env,XCLIP_TEST_DEPENDENCY_ROOT:project}});
 }finally{const resolved=fs.realpathSync(check);if(resolved!==check||!resolved.startsWith(project+path.sep))throw Error('TEMP_CLEANUP_PATH_REFUSED');fs.rmSync(resolved,{recursive:true,force:true});}
 console.log('STAGED_REGISTRATION_RECOVERY_TYPES_AND_TESTS_OK; HTTP/DB mocked');
}
const changes=[...before].filter(([rel,bytes])=>!bytes||!bytes.equals(Buffer.from(payload.files[rel])));
if(!changes.length){console.log('XCLIP_REGISTRATION_RECOVERY1000_'+(payload.scope==='local'?'LOCAL':'STAGED')+'_ALREADY_INSTALLED');process.exit(0);}
for(const[rel,bytes]of before){const now=fs.existsSync(target(rel))?fs.readFileSync(target(rel)):null;if(bytes===null?now!==null:!now||!now.equals(bytes))throw Error('CONCURRENT_EDIT_REFUSED');}
let backup;
if(payload.scope==='local'){
 backup='.local-admin/registration-recovery-backups/'+new Date().toISOString().replace(/[^0-9]/g,'')+'-'+crypto.randomBytes(4).toString('hex');
 put(backup+'/manifest.json',Buffer.from(JSON.stringify({version:1,release:payload.release,project,files:changes.map(([rel,bytes])=>({path:rel,before:bytes?.toString('base64')??null,installedHash:payload.hashes[rel]}))},null,2)));
}
try{for(const[rel]of changes)put(rel,Buffer.from(payload.files[rel]));}
catch(error){for(const[rel,bytes]of changes){if(bytes===null){if(fs.existsSync(target(rel)))fs.unlinkSync(target(rel));}else put(rel,bytes);}throw error;}
console.log('XCLIP_REGISTRATION_RECOVERY1000_'+(payload.scope==='local'?'LOCAL':'STAGED')+'_INSTALLED');
if(backup)console.log('BACKUP='+target(backup));
console.log('No env/DB/cron/patrol/removal/quota changes; installation provider requests0');
