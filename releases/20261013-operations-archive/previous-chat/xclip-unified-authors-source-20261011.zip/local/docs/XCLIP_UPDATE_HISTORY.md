# Xclip 更新履歴・引き継ぎ台帳

最終更新：2026-10-11（日本時間）。この台帳は作成・検証・ローカル適用・本番適用を区別します。ファイルの存在だけで本番反映済みとは判断しません。

## 現在の基準

- 現在の開発先：`C:\Projects\xcliprank`。`Documents\x_video_rank_mvp` は古い環境であり、現在の更新元として使わない。
- 本番：ColorfulBox、`https://xcliprank.com`。現在公開中のコードはサーバーの `.htaccess` にある `PassengerAppRoot` と、runtimeの `DEPLOY_SOURCE`・`.next/BUILD_ID` で照合する。古い会話のVercel向けデプロイ手順を現在の本番へそのまま適用しない。
- GitのHEADだけでは現状を表さない。現在のローカルには未コミット変更・未追跡ファイルがある。更新前にそれらを保護する。
- 今回のローカル修正は適用済み。本番用修正版は作成・検証済みで、サーバーでの実行結果は未受領。本番の再生不能動画の除外と、実DBへの再登録結果は未確認。
- 対応する成果物とローカルコードのSHA-256は `Xclip-更新照合台帳.json` に記録する。ハッシュは取得時点の内容を示し、適用済みの証明とは区別する。

## 過去の更新の復元

参照できた会話・ローカル文書・更新ファイルから復元したものです。全会話の完全な監査を済ませたという意味ではありません。過去の適用状況を確認できないものは、そのまま未確認と記載します。

| 日付・期間 | 内容 | 確認根拠・状態 |
|---|---|---|
| 2026-08〜09 | コンテンツフィルター、安全確認、手動除外・教師レビュー等の基盤 | 「Add content filter module」、現在の `lib/content-filter.ts` 等。全改版の本番適用日時は未照合。現在の保守で既存の手動除外や安全判定を上書きしない。 |
| 2026-09-07頃 | 投稿画像へのモザイク・ぼかし・JPEG変換、適用フラグ | 「Add content filter module」の当時の本番反映報告と、その後のユーザー動作確認。旧Vercel環境での履歴であり、現在のColorfulBox版との一致は未照合。 |
| 2026-09-07頃 | サイトとDBのバックアップ | 同会話に934ファイル・5テーブル13,191行のバックアップ報告。取得不能な機密変数等の不足も報告されている。完全復元可能との断定はしない。 |
| 2026-09-07頃 | 広域探索停止・選別投稿者100%への設定 | 同会話にローカル変更・型検査成功。本番デプロイは認証エラーで未反映との報告。その後の現行版と同一とは判断しない。 |
| 2026-09-13〜16 | 管理ハブ、アクセス・エンゲージメント、ローカル管理保護、開発先の固定 | 現在の文書、ローカルコード、保存済み更新アーカイブ。固定開発先は `C:\Projects\xcliprank`。当時のVercel運用文書は現在の公開方式と区別する。 |
| 2026-09-30 | ランキング流動性・SEOの調査 | 「Xclip流動性とSEO」。この調査時点では追加実装・Preview作成なし。後日のランキング改修と区別する。 |
| 2026-10-03 | 収集のページ継続、再開、公平な巡回順 | 「Xclip収集ログ確認」「Xclip収集の週次判断」、PR #7の反映済みとの過去報告。10/3の実行ログは24投稿者・287読み取り・39新規保存・248重複・実エラー0。現在の無料巡回とは別の有料収集経路の履歴。 |
| 2026-10-04 | 動画カードのTier・スコア非表示、再生時間表示 | 「Xclip収集ログ確認」に作成・検証と切り替え不具合の修正履歴。切り替え修正後のユーザー成功報告あり。 |
| 2026-10-04 | 新着・24時間ランキングの補充枠・重複回避 | 同会話に100件以上の表示、過去動画補充、日次枠85件、重複回避の改修と切り替え修正。ユーザー成功報告あり。今回の更新では配分・選択方法を変更していない。 |
| 2026-10-04〜05 | 収集検索範囲の期限切れ対策 | 「Xclip収集ログ確認」に更新ファイルと `curated_search_expiry` 追加手順。「Xclip収集の週次判断」では10/5本番反映済みとの運用記録。現在のDB列をこの作業から直接照合はしていない。 |
| 2026-10-06 | Tier再評価、教師データ分析、管理リンク、ローカルHost判定 | `docs/20261006-parallel-roadmap.md` と保存済み成果物。Host修正後のローカル正常動作は過去のユーザー報告。各モデルの本番反映・実精度の判定は別途必要。 |
| 2026-10-07〜08 | 複数フレーム、プレビュー互換、教師分析、順序調整、再現率検証、モデルリリース関連 | 現在の `docs/tier-*.md`、コード、保存済み更新ファイル。成果物ごとの版とSHA-256を照合台帳に保存。ファイルがあることを本番適用済みの根拠にしない。 |
| 2026-10-08〜09 | 動画保存の調査からローカル実装へ移行 | 「Implement video downloads and saves」は調査・変更案のみ。「Xclip収集ログ確認」では依存ファイル不足で初版/v2が停止し、v3へ修正、その後ユーザーがローカル保存成功を確認。調査のみの会話を完成版と誤認しない。 |
| 2026-10-10〜11 | 投稿URLからの保存、直接再生、HLS、再生回復、URL許可リスト、時間メタデータ、表示文言 | 現在のローカルコード、`xclip-direct-*`・`xclip-video-url-*`・`xclip-site-copy-duration-*` 等の保存済み更新ファイル。今回の本番修正は、これらを含む実際の公開ビルドのソースをコピーして変更する。各過去版の適用時刻は未照合。 |
| 2026-10-11 | 凍結アカウントの監視、投稿削除監視、低頻度巡回、診断ログ | 「Xclip監視ログ確認」の実ログと、suspended v3・lowload・diagnosticsの更新ファイル。15:17 JSTのログでは投稿2件が `message` 不在により判定不明となり途中休止。本番で旧監視が動いていたことを確認。 |
| 2026-10-11 | FxTwitter無料巡回への移行と本番同期認証の修正 | 「プロジェクト運用方針確認」に認証修正後の本番同期動作確認。ローカルには10:36 JSTの更新バックアップが存在。自動収集は最大8投稿者・3時間周期・同一対象24時間以上・通信5秒間隔。有料の手動/復旧経路と区別する。 |
| 2026-10-11 | プロフィールURLと100/200/300投稿による簡易登録・自動同期・掲載 | 同会話と11:11 JSTのローカル更新バックアップ。今回も登録・途中再開・既存データ保護のテストで確認。 |
| 2026-10-11 | 選別投稿者の巡回管理画面 | 「プロジェクト運用方針確認」で作成・検証済みと訂正済み。19:37 JSTのローカルバックアップとコードでローカル適用を確認。本番dashboard単体更新の実行結果は未確認。今回の本番用修正に含まれる。 |
| 2026-10-11 | 再生不能動画の除外・取得0件修正 | このチャットで作成・検証・ローカル適用。本番未適用。詳細は次項。 |

## 今回の更新：availability-curated-fix-20261011

### 変更

- `lib/post-status.ts`：message省略を許容し、ID・投稿者・公開状態・動画メタデータを照合。削除と非表示を区別し、引用先だけの非表示で親投稿を除外しない。動画情報不足では除外解除しない。
- `lib/availability-scan.ts`：投稿ごとの判定不明で監視全体を休止しない。削除・非表示は24時間以上離れた2回の確認と同一巡回の正常動画応答で確認してから除外。通信障害・制限の休止は維持。
- `lib/fxtwitter-curated.ts`：新規取得は通常のstatuses一覧。cursorに取得経路を記録し、旧media一覧の途中再開との混在を防止。外部サービス障害と空一覧を区別する。
- `lib/free-curated-scan.ts`：空一覧等の個別失敗で後続投稿者の巡回を止めない。既存投稿ID・累計・前回成功時刻を保持。
- 巡回管理の既存コードとテストを統合。DBへの保存時の手動指定、安全確認、重複保護を維持。

### 検証・適用

- 登録、保存、本番同期、巡回管理、状態監視、空応答と通信障害の区別、新旧cursor、誤除外防止、復旧の模擬テスト成功。
- 変更モジュールの型検査成功。配布した本番用ファイルの展開・照合・適用・再適用・未知版拒否を隔離コピーで確認。ローカル用ファイルの実適用成功。
- 実通信：`@yoyoyokun19` のmedia一覧0件、statuses一覧20投稿、動画候補10件。有料X API利用0件。候補抽出でありDB登録成功の報告ではない。
- ローカル適用：2026-10-11 20:52 JST。変更前バックアップ：`.local-admin/fxtwitter-curated-backups/20261011115212931-bd7faf`。
- 本番用：`xclip-availability-curated-fix-deploy-20261011.sh`。ローカル用：`xclip-availability-curated-fix-local-20261011.ps1`。SHA-256は照合台帳を参照。
- 本番の全体ビルドと公開後の確認はサーバーで更新ファイルを実行した際に行う。更新時に追加巡回・待機期限リセットは行わない。

## 2026-10-11：更新履歴の運用追加

ユーザー指示により、今後は更新ファイルをチャットへ直接添付し、実行方法もチャット本文へ記載する。更新履歴を継続し、以前の会話の更新も確認できた範囲で追記する。

- この台帳、成果物とコードの照合台帳、ローカルの `AGENTS.md` に確認ルールを保存する。
- 旧 `docs/development-workflow.md` には、Vercel手順が過去の記録であることと現在の台帳への参照を追記する。
- この変更は文書・運用ルールのみ。上記プログラム更新ファイルの内容は変えていない。

## 今後の各更新で必ず記録する項目

1. 日時（JST）、依頼元の会話、具体的な変更目的。
2. 基準にしたローカル/本番コード、対象ファイル、変更前後の照合値、既存の未コミット変更。
3. 更新ファイル名・版・SHA-256、前提と含まれる更新、置き換える旧版。
4. 実施した検証と結果、未確認事項。ビルド成功を本番反映済みと扱わない。
5. 作成済み/検証済み/ローカル適用済み/本番適用済み/復旧済みを別々に記録。
6. 適用先・時刻・成功表示・バックアップ先・復旧方法。共有されたサーバーログを根拠として追記する。

未確認の項目を推測で埋めず、次に確認する項目として残す。古い会話のコードより、実際に適用されているコードとその照合結果を優先して整合を確認する。

## 2026-10-11T21:20:56+09:00 : previous issue closed and recorded in Git

- User instruction: treat the availability and zero-result collection work as complete and record it in Git. This records completion of the requested work; it does not certify full collection success for every author.
- Screenshots supplied by the user show 43 and 25 published items, with author-specific fetching stopped partway through. No production database query or server installation log was supplied. Production deployment and end-to-end display remain unverified by this agent.
- Scope: local FxTwitter registration and monitoring UI, their directly related modules/tests, handoff rules/history, and the exact production/local installer artifacts plus the production source patch archive under $releaseRelative.
- Preserve unrelated download, playback, Tier-learning, collector and layout changes as uncommitted work. No application source changed in this recording operation. Release files match the previously recorded SHA-256 values; selected local source files were checked against the prior source snapshot.
- Prior tests/typecheck remain as recorded above; no new build, paid API request, collection, database change or deployment was run. The production source zip is a patch set for the detected deployed source, not a complete standalone application; the local and production source variants must remain distinct.
- Git commit is authorized in this conversation. GitHub push is not performed. The commit ID is recorded in the downloadable Git receipt after commit creation.
- User operating preference: do not operate the PC, apply local updates, or run commands without an explicit request. In ordinary update delivery, supply downloadable files, complete history and inline execution instructions for the user to execute. This Git recording and read-only feasibility review are the current explicitly requested operations.
- Next request is feasibility verification only: FxTwitter for author addition/bulk import; official X API for subsequent new-video polling. No implementation or scheduled-provider change is included in this completion commit.


## 2026-10-11：hybrid-xapi24-20261011（作成・模擬検証済み、未適用）

依頼：選別投稿者の追加と100/200/300投稿の一括取得はFxTwitterに残し、その後の新着動画巡回をX APIへ変更。直近24時間で最大24投稿者、前回以降の動画のみ。利用制限で中断した作成作業を継続し、登録の本番反映についても調査。

- 基準：Git 84bd6f49cbeed2372b07408104e5d0348ffc0ac7、現在のローカルと保存済みの本番向けavailability-curated-fix配布物。両者の差を保持。対象プログラムは隔離作業コピーで編集し、C:\Projects\xcliprankへの適用・本番操作・Git操作は今回は行っていない。
- 新着巡回：既存Cron入口のscan-free-curatedをX API専用処理へ転送。通常の旧有料バッチ入口は引き続き収集しない。別のCronは追加せず、同じflockとoperation.lockを使う。手動の明示的復旧経路は従来どおり。
- 上限：直近24時間で最大24投稿者、同一投稿者も24時間以上。3時間ごと最大8投稿者、1投稿者につき1回最大100投稿、続きは次の対象巡回で再開。通信前に予約を永続化し、再起動・再同期・失敗でも予約枠を戻さない。枠の時刻を再設定するデプロイ処理はない。
- 取得対象：from:投稿者 has:videos -is:retweet。前回IDまたは期限内start_timeを使用。両パラメータは同時に送らない。ページ送り中は検索終了時刻を固定し、DB保存完了まで前回IDを進めない。応答の投稿者IDとネイティブ動画URLを照合。不要なユーザー展開・プロフィール再取得は行わない。
- 引き継ぎ：本番専用state-v1.jsonの登録一覧・停止状態・集計を維持。旧FxTwitter巡回が途中なら下側の取得境界から引き継ぐ。X用cursor・利用予約・取得位置は同じ永続ディレクトリ内x-api-v1.jsonへ分離する。基準なしは本番の最新保存済み投稿を参照し、それもなければ有料の初回取得をせず、無料一括取得の完了を待つ。
- 新規登録：無料一括取得中はX巡回を待機。確認済みの最新投稿IDと完了情報を本番へ送る。既存X取得位置を後から一括取得の新しいIDで飛ばさない。動画候補0件のページでも登録完了情報を送る。
- 登録未反映の調査：ローカルに行があること、本番専用巡回一覧への同期、動画DBへの掲載、サイトの新着表示は別。従来の選別投稿者一覧はis_curated:trueを主に扱い、FxTwitter追加は専用一覧で管理する。画面を閉じる・取得/同期/掲載失敗で初回処理は止まり、途中再開が必要。
- 修正した復旧経路：本番側の登録が欠けた409を識別し、掲載段階で1回だけ登録一覧を再同期し、保存済みの同じページを掲載し直す。停止中・認証不良・DB失敗を自動解除しない。投稿者の停止・再開・登録解除は本番へ同期成功してからローカル状態を更新する。
- 表示：本番への反映確認、ローカル一覧との未同期比較、X API予約数・応答投稿数・日次利用枠・初回完了待ち・7日検索範囲外の警告を追加。監視画面の読み取りはFxTwitter/X APIを呼ばない。
- 既存保護：手動評価・手動非表示・安全除外・重複・凍結/削除/非表示の除外と復旧条件を維持。可用性監視は従来のFxTwitter系のまま、新着X巡回とは別。
- 検証：通信/DBを模擬した上限・再起動・予約・途中移行・ページ保存失敗・旧cursor混入拒否・空/不正/部分失敗応答・429/認証/残高/通信休止・登録復旧・停止・安全掲載・巡回管理・既存可用性監視のテスト成功。変更モジュール、登録APIと画面の型検査成功。本番全体の型検査/ビルドは実際の稼働ソースで更新時に行う。
- 配布検証：隔離コピーで本番パッチのステージ必須・未知版拒否・適用・再適用、ローカルパッチの未知版拒否・模擬テスト/型検査・適用・再適用・復元・登録データ保持を確認。配布shとps1の構文検査も成功。対象PCの実プロジェクトや本番への適用検証とは区別する。
- 制限：Recent Searchは過去7日。検索範囲外は明示して無料一括取得で補完する。大量投稿者の続きページは日次枠内で順次処理する。24時間に最大24投稿者なので、登録者数が24を超える場合は順番待ちになる。
- 個別投稿者の未反映原因は、ユーザーの対象名・エラー・本番ログが未受領のため断定していない。実API権限/残高、有料API実通信、実DB保存、本番表示は未確認。
- 配布：本番用sh、ローカル用ps1、版別ソース・テストZIP、累積履歴・照合台帳。各対象と成果物のSHA-256は同梱台帳・チェックサムに保存。本番更新は稼働ソース・BUILD_ID・想定ファイルhashを照合し、隔離ビルドと公開確認の後に同じCronを更新。未知版は拒否、切替失敗時は旧runtime/settingsへ復旧。ローカルは変更前バックアップと内容照合付き復元を用意。
- 今回の作成・検証だけでは適用済み扱いにしない。ユーザーが実行する。秘密の値・登録データ・環境ファイルは配布しない。

なお、前項のGit記録対象のリリース保存先はreleases/20261011-availability-curated。文字列$releaseRelativeと記録された箇所はこの保存先を指す。


## 2026-10-11：hybrid-xapi24 本番更新完了（ユーザー提供ログで確認）

2026-10-11 hybrid-xapi24-20261011 本番反映確認記録

証拠：ユーザーから提供された本番実行ログ。こちらから本番への接続・適用・API巡回・Git操作は行っていない。
結果：XCLIP_HYBRID_XAPI24_DEPLOYMENT_COMPLETE を確認。
本番：更新完了。ステージと公開後のページ、ランキング、Reels、登録同期API、巡回管理APIの確認成功。
巡回：既存Cron更新・runtime確認成功。X API新着巡回、FxTwitter追加/一括取得、直近24時間24投稿者、3時間ごと最大8投稿者、同一投稿者24時間以上。
起動待ち：最初のステージcurl接続拒否、切替直後の公開確認HTTP 503は、後続確認成功により解消。最終エラーではない。
バックアップ：/home/rbxfxmfd/xclip-before-hybrid-xapi24-20261011.tlXJaO/runtime
実行ステージ：/home/rbxfxmfd/xclip-hybrid-xapi24-20261011.Bds2LV
稼働AppRoot：/home/rbxfxmfd/xclip-video-card-20261004.DJKKID/runtime
実通信：この更新では収集APIを呼んでいない。X APIの認証・残高・実巡回・新着DB保存の成功は、後続の巡回実績で確認が必要。
ローカル：更新の実行結果は未受領。適用済みとは扱わない。
個別投稿者：反映されていない投稿者名・状態は未受領。原因は未確定。
次の操作：本番成功後、ローカル更新ps1をユーザーが実行し、開発サーバーを再起動。本番への反映確認と必要な途中再開を行う。
既存配布sh/ps1/ソースZIPおよびそのチェックサムは変更しない。


## 2026-10-11：新着掲載条件の調査

2026-10-11 追加調査（コード変更・本番操作なし）

ユーザーの質問：FxTwitter選別投稿者追加で取得した動画の新着掲載順位、巡回管理が除外監視かどうか。
確認対象：保存済み本番向けランキングコードとハイブリッド更新の掲載処理・巡回管理画面。
発見：free-curated-publish.tsは新規authorsをis_curated:falseで作成する。一方、rankings/route.tsのfetchActiveCuratedAuthorIdsはis_curated:trueかつcurated_status:activeのみ取得し、fetchCandidatePoolはそのauthor_idだけに限定する。
影響：この条件のままのランキング実装では、新たにFxTwitter側だけで登録した投稿者の動画は、公開可能なDB行として保存済みでもランキング候補から外れる。既に通常の選別投稿者条件を満たす投稿者は影響が異なる。
個別確認：ユーザー提供画面の10/10は本番専用巡回一覧への同期成功を示し、サイトのランキング表示を証明しない。本番の個別DB行・現時点のランキングソースは直接確認していない。
並び順：created_atは元のX投稿日時。追加登録日時を新着日時へ置き換えない。古い一括取得分は過去枠と評価条件に従う。
巡回管理：fxtwitter-monitorは新着動画の取得巡回記録。更新後はX APIの取得・掲載件数・最終実行・待機状態を表示する。凍結・削除・非表示を確認する既存動画の可用性監視とは別。
訂正：過去説明の「本番掲載」はDB保存・公開可能状態への変更成功を指し、ランキング候補への採用や実表示まで保証しない。この条件差を前回の説明では把握できていなかった。
更新方針候補：新着/各ランキングの対象投稿者集合へ、専用登録一覧の対象投稿者を含める。is_curatedを一律trueにして旧収集へ再投入する方法は、二重巡回防止との整合が必要。今回は質問への調査のみで修正・配布更新は実施していない。


## 2026-10-11：unified-authors-20261011（作成・模擬検証済み、未適用）

- 依頼：通常登録とFxTwitter登録を同じ管理情報に統合。再生不可動画の監視画面を追加。凍結・非表示の投稿者を管理者が削除できるようにする。
- 基準：本番適用ログで確認済みのhybrid-xapi24-20261011とその照合済み配布コード。ローカル適用は未確認なので、直前版と以前の既知版を内容照合して更新できるようにする。実プロジェクト・本番への適用とGit操作は今回行っていない。
- 共通管理：authorsのis_curated=true、curated_status、期待Tier等を通常登録と共有。ローカルのFx登録ファイルは初回取得の途中再開用、サーバーの巡回ファイルは取得位置・予約・統計用に残し、投稿者の稼働状態はDBを参照する。旧通常登録画面は共通管理へ案内し、追加はFxTwitterの共通導線を使う。
- 既存移行：既に同期済みのサーバー登録一覧を共通DBへ反映。動画の再取得、有料API、取得位置・予約枠のリセットはしない。既存の共通停止状態、評価・手動指定を維持。正常デプロイでは公開切替後に移行CLIを実行する。再試行は共通管理画面から可能。
- 掲載条件の修正：FxTwitter新規投稿者のDB保存をis_curated:falseから共通管理のis_curated:trueへ変更。既存の新着・ランキング側の候補条件に入る。元の投稿日時・Tier・安全除外・重複条件は維持し、古い動画が必ず新着上位に来るとは扱わない。
- 状態同期：停止・再開・削除は投稿者単位で本番へ操作。部分的なローカル一覧の同期で、他の投稿者を停止したり、停止中の投稿者を再開しない。新着CronはDBの共通状態を照合する。同じCron・operation.lock・24時間最大24投稿者・Xの取得境界を維持。
- 手動削除：共通管理と追加画面に確認付き削除。削除記録を永続化してから、DBの投稿者をremoved/is_curated:falseへ変更し、その投稿者の動画をis_visible:falseにする。DB行と評価履歴は復旧用に保持し、物理削除しない。手動削除キーを既存の公開・ランキング・Reels・ダウンロード除外判定に統合し、監視による自動復旧・古い一覧の同期・再開・再掲載で復活しない。途中DB失敗は削除済み一覧から再試行可能。成功時に巡回一覧から除き、枠の時刻とX位置は保持する。
- 再生不可監視：本番のアカウント/投稿状態ファイルを認証済みAPI経由で読み、最終確認、確定除外、再確認待ち、凍結、手動削除、次回最短時刻・休止・一巡完了をローカルの/availability-monitorへ表示。各詳細は最新最大500件。画面の更新は外部プロバイダ取得・DB更新・巡回の強制実行をしない。全実行ログではなく最新状態の確認画面。24時間離した確認とhealthy-control等の自動除外基準は変更しない。
- 導線：管理トップに/curated-managerと/availability-monitorを追加。既存のカードや未知の編集を丸ごと上書きせず、構文を確認して必要なカードだけ追記。ローカル画面はproductionで404、操作APIはlocalhost同一オリジンJSONのみ、本番APIはCRON_SECRETとDB接続先照合を維持。
- 検証：実DB/HTTPを模擬し、共通移行、ランキング候補条件、保存、停止の権威、部分一覧同期、削除確認、DB失敗再試行、再同期/自動復旧による復活防止、予約・cursor保持、監視の読み取り専用、ローカル操作の認証・状態保持を確認。既存の上限・ページ送り・登録復旧・可用性監視テストと変更箇所の型検査成功。複数TSX変更後にReactの確認スキルで読み込み・操作状態・エラー表示を確認。画面のPC操作による検証は行っていない。
- 配布検証：隔離コピーで本番パッチのステージ必須・未知版拒否・適用・再適用と、その適用後ソースの共通管理/既存巡回/可用性テストを確認。ローカルパッチの未知版拒否・模擬テスト/型検査・適用・再適用・復元・登録データ保持を確認。sh/ps1構文検査成功。
- 配布/適用：本番sh、ローカルps1、版別ソースZIP、累積履歴、照合台帳、SHA-256。実本番ソースで型検査・ビルド・ステージ/公開確認を行ってから完了する。未知版拒否、runtime/settingsの自動復旧、ローカルのファイルバックアップ/照合付き復元を継承。
- 復旧の範囲：公開切替失敗時は前runtime/settingsへ戻す。共通DBへの移行済みフラグは自動巻き戻ししない（動画・評価・取得位置は消さない）。手動削除した動画もインストーラー復元では再掲載しない。移行のDB更新失敗はデプロイを完了扱いにせず、ログと画面から再確認・再試行する。
- 状態：この版は未適用。実際の新着表示、実巡回、個別アカウント削除はユーザー実行後のログで確認する。秘密の値・実登録データ・環境ファイルは同梱しない。
