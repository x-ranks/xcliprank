v3 supersedes v1/v2; monitor tests now isolate inherited manual removals. Operational logic/scheduler unchanged from v2. Use installers. No secrets or real state.
