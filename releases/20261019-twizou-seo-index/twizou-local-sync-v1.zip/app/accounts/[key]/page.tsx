import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import PublicVideoCards from "../../components/PublicVideoCards";
import { PUBLIC_SITE } from "../../../lib/public-video-core";
import { readPublicAccount } from "../../../lib/public-video-server";
import { SITE_NAME } from "../../../lib/seo";
export const dynamic = "force-dynamic";
type Props = { params: Promise<{ key: string }> };
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { key } = await params, d = await readPublicAccount(key);
  if (!d) return { title: "投稿者が見つかりません", robots: { index: false, follow: true } };
  const canonical = `${PUBLIC_SITE}/accounts/${encodeURIComponent(d.canonicalKey)}`;
  const title = `${d.name}の動画｜${SITE_NAME}`;
  const example = Array.from(d.videos.map(v => v.text?.replace(/https?:\/\/t\.co\/\S+/gi, "").replace(/\s+/g, " ").trim()).find(Boolean) ?? "").slice(0, 55).join("");
  const description = `${d.name}の掲載可能な動画${d.videos.length}件を紹介します。${example ? `内容例：${example}。` : ""}投稿と関連動画を確認できます。`;
  const images = d.videos.find(v => v.posterUrl)?.posterUrl;
  return { title: { absolute: title }, description, alternates: { canonical }, robots: { index: d.index, follow: true },
    openGraph: { type: "website", title, description, url: canonical, ...(images ? { images: [images] } : {}) },
    twitter: { card: "summary_large_image", title, description, ...(images ? { images: [images] } : {}) } };
}
export default async function AccountPage({ params }: Props) {
  const { key } = await params, d = await readPublicAccount(key); if (!d) notFound();
  return <main style={{ maxWidth: 1120, margin: "0 auto", padding: 24 }}><Link href="/">新着一覧</Link><h1>{d.name}の動画</h1><p>{d.name}の掲載可能な動画{d.videos.length}件を紹介しています。</p><PublicVideoCards videos={d.videos} /></main>;
}
