# 個別URLランキング登録：ローカル認証修正

本番への再適用は不要です。ローカルの個別URL登録画面が入力済みの管理キーを本番APIへ渡すよう、ローカルの3ファイルだけを更新します。本番側は自身の `CRON_SECRET` で認証を続けます。管理キーはこのチャットに送らないでください。

ローカル開発サーバーを停止し、このZIPを展開したフォルダーでPowerShellから実行します。

```powershell
node .\apply-local.cjs --check
node .\apply-local.cjs --apply
```

成功表示は `LOCAL_SYNC_APPLIED files=3` です。`LOCAL_BACKUP=` と成功表示を共有してください。自動検査が失敗した場合は3ファイルをバックアップから自動復元します。手動で戻す場合は、成功時のバックアップ先を指定して `node .\apply-local.cjs --rollback "バックアップ先"` を実行します。

サーバー再起動後、`http://localhost:3000/manual-ranking` を開き、既に入力済みのキーで状態を再読込してください。本番のキーと異なる場合は「管理キーを変更」を押し、本番側に設定した `CRON_SECRET` を入力します。アプリの通常のログイン用パスワードとは別のキーです。
