import { readPublicIndex } from "../lib/public-video-server";
export const dynamic = "force-dynamic";
import type { MetadataRoute } from "next";
import { SITE_URL } from "../lib/seo";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  // Fail visibly on a database error; an empty sitemap would falsely signal removals.
  const index = await readPublicIndex();
  return [
    { url: SITE_URL },
    { url: `${SITE_URL}/ranking/daily` },
    { url: `${SITE_URL}/ranking/weekly` },
    { url: `${SITE_URL}/download` },
    ...index.posts.map(p => ({ url: `${SITE_URL}/p/${p.id}`, ...(p.modifiedAt ? { lastModified: p.modifiedAt } : {}) })),
    ...index.accounts.map(a => ({ url: `${SITE_URL}/accounts/${encodeURIComponent(a.key)}`, ...(a.modifiedAt ? { lastModified: a.modifiedAt } : {}) }))
  ];
}
