'use strict';
// v1: encrypted, streaming file snapshots. Never writes into a live application.
const fs=require('fs'), fsp=fs.promises, path=require('path'), crypto=require('crypto');
const {Readable,Transform}=require('stream'), {pipeline}=require('stream/promises');
const zlib=require('zlib'), readline=require('readline'), cp=require('child_process');
const MAGIC=Buffer.from('XCLIPBK1'), HEADER=36;
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const inside=(root,p)=>p===root||p.startsWith(root+path.sep);
function safeName(s){if(typeof s!=='string'||!s||s.includes('\\')||s.includes('\0')||s.split('/').some(p=>!p||p==='.'||p==='..')||/^[A-Za-z]:/.test(s)||s.startsWith('/'))throw Error('UNSAFE_ARCHIVE_PATH');return s;}
function key(salt){const p=process.env.XCLIP_BACKUP_PASSWORD; if(!p||p.length<12)throw Error('BACKUP_PASSWORD_MINIMUM_12_CHARACTERS');return crypto.scryptSync(p,salt,32,{N:32768,r:8,p:1,maxmem:64*1024*1024});}
async function hashFile(p){const h=crypto.createHash('sha256');for await(const b of fs.createReadStream(p))h.update(b);return h.digest('hex');}
async function encrypt(records,dest){
 const salt=crypto.randomBytes(16),iv=crypto.randomBytes(12),head=Buffer.concat([MAGIC,salt,iv]);
 const c=crypto.createCipheriv('aes-256-gcm',key(salt),iv);c.setAAD(head);
 const sink=fs.createWriteStream(dest,{flags:'wx',mode:0o600});sink.write(head);
 await pipeline(Readable.from(records),zlib.createGzip(),c,sink,{end:false});
 await new Promise((resolve,reject)=>{sink.on('error',reject);sink.end(c.getAuthTag(),resolve);});
}
async function decryptStream(file){
 const st=await fsp.stat(file);if(st.size<HEADER+16)throw Error('INVALID_ARCHIVE');
 const h=await fsp.open(file,'r'),head=Buffer.alloc(HEADER),tag=Buffer.alloc(16);
 try{await h.read(head,0,HEADER,0);await h.read(tag,0,16,st.size-16);}finally{await h.close();}
 if(!head.subarray(0,8).equals(MAGIC))throw Error('INVALID_ARCHIVE');
 const d=crypto.createDecipheriv('aes-256-gcm',key(head.subarray(8,24)),head.subarray(24,36));d.setAAD(head);d.setAuthTag(tag);
 return {source:fs.createReadStream(file,{start:HEADER,end:st.size-17}),decipher:d};
}
async function authenticate(file){const {source,decipher}=await decryptStream(file);await pipeline(source,decipher,new Transform({transform(b,e,cb){cb();}}));}
async function unpack(file,dest){
 // Authenticate before creating plaintext files. Restoration is only into a NEW directory.
 await authenticate(file);
 if(fs.existsSync(dest))throw Error('RESTORE_TARGET_ALREADY_EXISTS');
 await fsp.mkdir(dest,{mode:0o700});
 if(process.platform==='win32'){
  const sid=cp.execFileSync('whoami',['/user','/fo','csv','/nh'],{encoding:'utf8'}).match(/S-1-[0-9-]+/)?.[0];
  if(!sid)throw Error('PRIVATE_RESTORE_ACL_FAILED');
  cp.execFileSync('icacls',[dest,'/inheritance:r','/grant:r',`*${sid}:(OI)(CI)F`],{stdio:'pipe'});
 }
 const {source,decipher}=await decryptStream(file),gun=zlib.createGunzip();
 const reading=pipeline(source,decipher,gun); reading.catch(()=>{});
 const lines=readline.createInterface({input:gun,crlfDelay:Infinity});
 let current=null,count=0,summary=null;const seen=new Set();
 try{
  for await(const line of lines){const r=JSON.parse(line);
   if(r.t==='file'){
    if(current)throw Error('INVALID_RECORD_ORDER');const n=safeName(r.n);if(seen.has(n))throw Error('DUPLICATE_FILE');seen.add(n);
    const target=path.resolve(dest,...n.split('/'));if(!inside(path.resolve(dest),target))throw Error('UNSAFE_RESTORE_TARGET');
    await fsp.mkdir(path.dirname(target),{recursive:true,mode:0o700});
    current={n,h:crypto.createHash('sha256'),bytes:0,handle:await fsp.open(target,'wx',r.mode&0o777)};
   }else if(r.t==='data'){
    if(!current)throw Error('INVALID_RECORD_ORDER');const b=Buffer.from(r.b,'base64');current.h.update(b);current.bytes+=b.length;await current.handle.writeFile(b);
   }else if(r.t==='end'){
    if(!current)throw Error('INVALID_RECORD_ORDER');await current.handle.close();
    if(current.h.digest('hex')!==r.sha256||current.bytes!==r.bytes)throw Error('RESTORE_HASH_MISMATCH');current=null;count++;
   }else if(r.t==='summary'){if(summary||current)throw Error('INVALID_SUMMARY');summary=r;}
   else throw Error('UNKNOWN_RECORD');
  }
  await reading;if(current||!summary||summary.files!==count)throw Error('INCOMPLETE_ARCHIVE');
  return {files:count,summary};
 }finally{if(current)await current.handle.close().catch(()=>{});lines.close();}
}
async function listTree(root,label,exclude=[]){
 const result=[];
 async function walk(dir,rel){for(const e of await fsp.readdir(dir,{withFileTypes:true})){
  const r=rel?rel+'/'+e.name:e.name;if(exclude.some(x=>r===x||r.startsWith(x+'/'))||e.name==='operation.lock'||e.name==='lookup-free-v2.lock')continue;
  const p=path.join(dir,e.name),st=await fsp.lstat(p);
  if(st.isSymbolicLink())throw Error('SYMLINK_REQUIRES_SEPARATE_BACKUP');
  if(st.isDirectory())await walk(p,r);else if(st.isFile())result.push({p,n:safeName(label+'/'+r),mode:st.mode,bytes:st.size});else throw Error('SPECIAL_FILE_REQUIRES_SEPARATE_BACKUP');
 }}await walk(root,'');return result.sort((a,b)=>a.n.localeCompare(b.n));
}
async function compareRelease(root,kind){
 const file=path.join(__dirname,'xclip-baseline-20261012.json');if(!fs.existsSync(file))throw Error('BASELINE_MANIFEST_MISSING');
 const entries=JSON.parse(fs.readFileSync(file,'utf8'))[kind],result=[];
 for(const e of entries){const p=path.join(root,...e.path.split('/'));result.push({path:e.path,expected:e.sha256,actual:fs.existsSync(p)?await hashFile(p):null});}
 return {scope:'Latest unified-authors patch targets only; not the entire project.',matched:result.filter(e=>e.actual===e.expected).length,differences:result.filter(e=>e.actual!==e.expected)};
}
async function snapshot(roots,folder,metadata,extras=[],guard=async()=>{}){
 folder=path.resolve(folder);
 for(const r of roots)if(inside(path.resolve(r.root),folder))throw Error('BACKUP_MUST_BE_OUTSIDE_SOURCE');
 await fsp.mkdir(folder,{recursive:false,mode:0o700});
 const entries=[];for(const r of roots)entries.push(...await listTree(r.root,r.label,r.exclude||[]));
 const hashes=[];
 async function* records(){
  for(const e of [...entries,...extras]){
   yield JSON.stringify({t:'file',n:e.n,mode:e.mode||0o600})+'\n';
   const h=crypto.createHash('sha256');let bytes=0;
   const stream=e.data!==undefined?Readable.from([Buffer.from(e.data)]):fs.createReadStream(e.p,{highWaterMark:64*1024});
   for await(const b of stream){h.update(b);bytes+=b.length;yield JSON.stringify({t:'data',b:b.toString('base64')})+'\n';}
   const digest=h.digest('hex');hashes.push({n:e.n,sha256:digest,bytes});
   yield JSON.stringify({t:'end',sha256:digest,bytes})+'\n';
  }
  yield JSON.stringify({t:'summary',version:1,files:hashes.length,metadata,hashes})+'\n';
 }
 const archive=path.join(folder,'snapshot.xclipbk');await encrypt(records(),archive);
 // Detect changes while reading. A changed snapshot must not be reported as consistent.
 const indexed=new Map(hashes.map(h=>[h.n,h]));
 for(const e of entries){const expected=indexed.get(e.n);if(await hashFile(e.p)!==expected.sha256)throw Error('SOURCE_CHANGED_RETRY_WHILE_IDLE');}
 for(const r of roots){const again=await listTree(r.root,r.label,r.exclude||[]);if(JSON.stringify(again.map(e=>e.n))!==JSON.stringify(entries.filter(e=>e.n.startsWith(r.label+'/')).map(e=>e.n)))throw Error('SOURCE_FILE_LIST_CHANGED');}
 const restored=await unpack(archive,path.join(folder,'restore-test'));
 await guard();
 const report={version:1,createdAtJst:new Date().toLocaleString('sv-SE',{timeZone:'Asia/Tokyo'}),files:restored.files,archiveSHA256:await hashFile(archive),fileRestore:'PASS',...metadata,
  limitations:['DB restoration is separate.','GitHub is not a backup of runtime data.','External providers and Storage object bodies are not copied.','restore-test contains private plaintext; do not upload it.']};
 await fsp.writeFile(path.join(folder,'SAFE-REPORT.json'),JSON.stringify(report,null,2),{mode:0o600,flag:'wx'});
 console.log('XCLIP_FILE_SNAPSHOT_AND_RESTORE_OK');console.log('BACKUP_DIRECTORY='+folder);console.log('SHARE_ONLY=SAFE-REPORT.json');
 return report;
}
async function main(){
 const [action,a,b,c]=process.argv.slice(2);
 if(action==='local'){
  const root=fs.realpathSync(a);if(!fs.existsSync(path.join(root,'package.json'))||!fs.existsSync(path.join(root,'app')))throw Error('PROJECT_LAYOUT_MISSING');
  if(fs.existsSync(path.join(root,'.local-admin/fxtwitter-curated-v1/operation.lock')))throw Error('LOCAL_REGISTRATION_BUSY');
  let head=null;try{head=cp.execFileSync('git',['-C',root,'rev-parse','HEAD'],{encoding:'utf8'}).trim();}catch{}
  if(!fs.existsSync(path.join(root,'.git'))||!fs.lstatSync(path.join(root,'.git')).isDirectory())throw Error('GIT_DIRECTORY_REQUIRES_SEPARATE_BACKUP');
  return snapshot([{root,label:'project',exclude:['node_modules','.next','.turbo']}],b,{kind:'local',gitHead:head,dbRestore:'PENDING',releaseComparison:await compareRelease(root,'local')});
 }
 if(action==='server'){
  const account=fs.realpathSync(a),ht=path.join(account,'public_html/.htaccess'),text=fs.readFileSync(ht,'utf8');
  const match=[...text.matchAll(/^\s*PassengerAppRoot\s+"([^"]+)"\s*$/gm)];if(match.length!==1)throw Error('UNEXPECTED_APP_ROOT');
  const runtime=fs.realpathSync(match[0][1]);if(!inside(account,runtime))throw Error('RUNTIME_OUTSIDE_ACCOUNT');
  const source=fs.realpathSync(fs.readFileSync(path.join(runtime,'DEPLOY_SOURCE'),'utf8').trim());if(!inside(account,source)||source===runtime)throw Error('SOURCE_OUTSIDE_ACCOUNT');
  const build=fs.readFileSync(path.join(runtime,'.next/BUILD_ID'),'utf8').trim();if(build!==fs.readFileSync(path.join(source,'.next/BUILD_ID'),'utf8').trim())throw Error('SOURCE_BUILD_MISMATCH');
  const roots=[{root:runtime,label:'runtime'},{root:source,label:'source',exclude:['node_modules','.next','.turbo']}],missing=[];
  for(const [env,def,label] of [['XCLIP_FREE_CURATED_STATE_DIR','.xclip-free-curated','free-state'],['XCLIP_AUTHOR_STATE_DIR','.xclip-author-status','availability-state'],['XCLIP_DOWNLOAD_STATE_DIR','.xclip-download','download-state']]){
   const raw=process.env[env]||path.join(account,def);if(!path.isAbsolute(raw))throw Error('STATE_PATH_NOT_ABSOLUTE');
   if(fs.existsSync(raw)){const root=fs.realpathSync(raw);if(!inside(account,root)||roots.some(r=>inside(r.root,root)))throw Error('STATE_PATH_REQUIRES_REVIEW');roots.push({root,label});}else missing.push(label);
  }
  if(missing.includes('free-state')||missing.includes('availability-state'))throw Error('REQUIRED_STATE_MISSING');
  const registry=roots.find(r=>r.label==='free-state').root,lock=path.join(registry,'operation.lock');await fsp.mkdir(lock,{mode:0o700});
  try{
   const extras=[{n:'settings/htaccess',data:text}],cron=cp.spawnSync('crontab',['-l'],{encoding:'utf8'});
   if(cron.status!==0)throw Error('CRONTAB_READ_FAILED');extras.push({n:'settings/crontab.txt',data:cron.stdout});
   for(const name of fs.readdirSync(account).filter(n=>/^xclip.*\.sh$/.test(n))){const p=path.join(account,name);if(fs.lstatSync(p).isFile())extras.push({n:'settings/scripts/'+name,p});}
   const report=await snapshot(roots,b,{kind:'server',runtime,source,buildId:build,missingOptional:missing,dbRestore:'PENDING',releaseComparison:await compareRelease(source,'production'),consistency:'File hashes verified; DB dump is a separate snapshot. Coordinate maintenance for an atomic recovery point.'},extras,async()=>{
    if(fs.readFileSync(ht,'utf8')!==text||fs.readFileSync(path.join(runtime,'.next/BUILD_ID'),'utf8').trim()!==build)throw Error('LIVE_VERSION_CHANGED');
    const current=cp.spawnSync('crontab',['-l'],{encoding:'utf8'});if(current.status!==0||current.stdout!==cron.stdout)throw Error('CRONTAB_CHANGED');
   });
   return report;
  }finally{await fsp.rmdir(lock);}
 }
 if(action==='file'){
  const p=path.resolve(a),expected=await hashFile(p);
  return snapshot([],b,{kind:'database-file',dbRestore:'PENDING',dumpSHA256:expected,validation:'Encrypted file round-trip only; pg_restore list is not DB restoration.'},[{p,n:'database/database.dump'}],async()=>{if(await hashFile(p)!==expected)throw Error('DUMP_CHANGED_DURING_BACKUP');});
 }
 if(action==='restore'){const r=await unpack(path.resolve(a),path.resolve(b));console.log('XCLIP_ISOLATED_FILE_RESTORE_OK; files='+r.files);return;}
 throw Error('USAGE: local PROJECT NEW_BACKUP | server ACCOUNT NEW_BACKUP | file DUMP NEW_BACKUP | restore ARCHIVE NEW_EMPTY_PATH');
}
if(require.main===module)main().catch(e=>{console.error('XCLIP_BACKUP_FAILED: '+(e.code||e.message));process.exitCode=1;});
module.exports={snapshot,unpack,authenticate,hashFile,safeName};
