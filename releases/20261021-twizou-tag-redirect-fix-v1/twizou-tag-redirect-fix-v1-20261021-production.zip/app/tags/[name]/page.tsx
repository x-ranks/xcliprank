import type { Metadata } from "next";
import { notFound, permanentRedirect } from "next/navigation";
import PublicVideoCards from "../../components/PublicVideoCards";
import { PUBLIC_SITE, tagHref } from "../../../lib/public-video-core";
import { SITE_NAME } from "../../../lib/seo";
import { readPublicTag } from "../../../lib/public-video-server";
export const dynamic = "force-dynamic";
type Props = { params: Promise<{ name: string }>; searchParams?: Promise<{ page?: string | string[] }> };
async function readPage(props: Props) {
  const { name } = await props.params, search = await props.searchParams;
  const raw = search?.page;
  if (raw !== undefined && (typeof raw !== "string" || !/^[1-9]\d{0,3}$/.test(raw))) notFound();
  const page = raw === undefined ? 1 : Number(raw);
  return { d: await readPublicTag(name, page), page, name };
}
export async function generateMetadata(props: Props): Promise<Metadata> {
  const { d, page } = await readPage(props);
  if (!d) return {};
  const title = `${d.label.name}の動画｜${SITE_NAME}`;
  const description = `${d.label.name}に関連する掲載可能な動画${d.videos.length}件を紹介します。動画の投稿者と元投稿を確認できます。`;
  const canonical = PUBLIC_SITE + tagHref(d.label) + (page > 1 ? `?page=${page}` : "");
  const poster = d.videos.find(video => video.posterUrl)?.posterUrl;
  return { title: { absolute: title }, description, alternates: { canonical }, robots: { index: d.index, follow: true },
    openGraph: { title, description, url: canonical, ...(poster ? { images: [poster] } : {}) },
    twitter: { card: poster ? "summary_large_image" : "summary", title, description, ...(poster ? { images: [poster] } : {}) } };
}
export default async function TagPage(props: Props) {
  const { name, d, page } = await readPage(props); if (!d) notFound();
  const base = tagHref(d.label);
  // App Router may provide a decoded name or the percent-encoded route segment.
  // Comparing the encoded segment to the display name redirects to the same URL forever.
  const sameRoute = (value: string) => value.replace(/%[0-9a-f]{2}/gi, escape => escape.toUpperCase());
  if (name.normalize("NFC") !== d.label.name && sameRoute(name) !== sameRoute(encodeURIComponent(d.label.name)))
    permanentRedirect(base + (page > 1 ? `?page=${page}` : ""));
  const returnTo = base + (page > 1 ? `?page=${page}` : "");
  return <main style={{ maxWidth: 1120, margin: "0 auto", padding: 24 }}><a href="/tags">ラベル一覧</a><h1>{d.label.name}の動画</h1>
    <p>{d.totalCount}件中 {page} / {d.totalPages}ページ</p>
    {d.videos.length ? <PublicVideoCards videos={d.videos} returnTo={returnTo} nativeNavigation /> : <p>現在掲載できる動画はありません。</p>}
    <nav aria-label="ラベルの動画ページ" style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
      {Array.from({ length: d.totalPages }, (_, i) => <a key={i} href={i === 0 ? base : `${base}?page=${i + 1}`}
        aria-current={i + 1 === page ? "page" : undefined}>{i + 1}</a>)}
    </nav></main>;
}
