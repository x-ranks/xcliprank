production/ and local/ are distinct target patch sets. Use the supplied installers. Do not overwrite an entire application with this archive. No environment or registry files included.
