# twizou 投稿URLから通常動画として登録・本番更新

X投稿URLからFxTwitter v2の `GET /2/status/{id}` を取得し、投稿者ID、名前、本文、投稿日、ネイティブ動画を確認します。通常のFxTwitter新着巡回と同じ `publishFreeCandidates` に渡すため、内容・Tier・停止/削除・重複・既存手動評価の条件を維持します。新しい投稿者は共通管理と3時間ごとの新着巡回へ追加し、入力した投稿IDを開始位置にします。過去投稿の一括取得は行いません。URL登録による順位の固定もしません。

前提：twizou SEO followup v1、個別URLランキングのbridge v1が本番へ適用済み。本更新は既存Cronや監視ラッパーを変更しません。差分5ファイルの基準SHA-256が一致しない場合は適用を停止します。

```bash
mkdir -p /home/rbxfxmfd/twizou-fx-post-url-v1-20261020
unzip -q /home/rbxfxmfd/twizou-fx-post-url-production-v1.zip -d /home/rbxfxmfd/twizou-fx-post-url-v1-20261020
bash /home/rbxfxmfd/twizou-fx-post-url-v1-20261020/apply-production.sh --check
bash /home/rbxfxmfd/twizou-fx-post-url-v1-20261020/apply-production.sh --apply
```

本番インストーラーは隔離テスト、型検査、ビルド、公開経路確認をしてから切り替えます。失敗時は旧runtimeを自動復元します。失敗表示が出たら再実行せず出力を共有してください。

成功表示：`CURRENT_SOURCE_AND_FX_POST_PAYLOAD_HASHES_MATCH`、`STAGED_PAYLOAD_FILES_COPIED=5`、`FX_POST_URL_AUTH_CHECK_OK`、`PREVIOUS_RUNTIME_BACKUP=...`、`NEW_BUILD_ID=...`、`TWIZOU_FX_POST_URL_V1_DEPLOYMENT_COMPLETE`。この認証確認は無効キーの拒否のみで、実投稿の取得・登録はしません。

本番が成功してからローカル更新を行い、実際のX投稿URLを1件登録して通常の新着・投稿者画面を確認してください。管理キーや環境変数の値は共有しないでください。
