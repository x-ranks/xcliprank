const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const packageRoot = __dirname;
const projectRoot = process.env.XCLIP_PROJECT_ROOT || "C:\\Projects\\xcliprank";
const ts = require(path.join(projectRoot, "node_modules/typescript"));
const source = fs.readFileSync(path.join(packageRoot, "app/components/PublicPostEngagement.tsx"), "utf8");
const calls = [];
let effect;
const moduleObject = { exports: {} };
const resolve = (name) => {
  if (name === "react") return { useEffect: (run) => { effect = run; } };
  if (name.endsWith("engagement-client")) return { trackEngagement: (event) => calls.push(event) };
  if (name === "react/jsx-runtime") return require(path.join(projectRoot, "node_modules/react/jsx-runtime"));
  throw Error(`Unexpected import: ${name}`);
};
new Function("require", "module", "exports", ts.transpileModule(source, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, jsx: ts.JsxEmit.ReactJSX, esModuleInterop: true },
}).outputText)(resolve, moduleObject, moduleObject.exports);
const Tracker = moduleObject.exports.default;
for (const [sourcePage, range] of [["/", "trending"], ["/ranking/daily?edition=one", "daily"], ["/ranking/weekly", "weekly"], ["/reels", "reels"], ["/tags/example", undefined], [null, undefined]]) {
  effect = undefined;
  assert.equal(Tracker({ postId: "2111989753172345043", sourcePage }), null);
  assert.equal(typeof effect, "function");
  effect();
  assert.deepEqual(calls.pop(), { eventType: "video_open", xPostId: "2111989753172345043", range, source: "post_detail" });
}
const page = fs.readFileSync(path.join(packageRoot, "app/p/[id]/page.tsx"), "utf8");
assert.match(page, /<PublicPostEngagement postId=\{v\.id\} sourcePage=\{sourcePage\}/);
assert.match(page, /const sourcePage = safePublicReturn\(query\?\.from\)/);
console.log("PASS: detail page records video_open for ranking, reels, tag and direct visits");
