'use strict';
// Offline, hash-guarded local-only installer. Never reads .env or runtime teacher/model state.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const here=__dirname,args=process.argv.slice(2),option=name=>{const i=args.indexOf(name);return i<0?null:args[i+1];};
const specified=option('--project');if(!specified)throw Error('PROJECT_REQUIRED');
const root=path.resolve(specified),manifest=JSON.parse(fs.readFileSync(path.join(here,'manifest.json'),'utf8'));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const token=manifest.release;
function inside(base,file){const rel=path.relative(base,file);return rel!==''&&!rel.startsWith('..')&&!path.isAbsolute(rel);}
function safe(file,kind='file'){
 if(!inside(root,file)&&file!==root)throw Error('PATH_OUTSIDE_PROJECT');
 const rel=path.relative(root,file),parts=rel?rel.split(path.sep):[];let current=root;
 for(let i=-1;i<parts.length;i++){
  if(i>=0)current=path.join(current,parts[i]);
  if(!fs.existsSync(current)){try{if(fs.lstatSync(current).isSymbolicLink())throw Error('SYMLINK_REFUSED');}catch(e){if(e.code!=='ENOENT')throw e;}continue;}
  const stat=fs.lstatSync(current);if(stat.isSymbolicLink())throw Error('SYMLINK_REFUSED');
  if(i<parts.length-1||kind==='directory'){if(!stat.isDirectory())throw Error('NOT_A_DIRECTORY');}else if(!stat.isFile())throw Error('NOT_A_FILE');
 }
}
function atomic(file,bytes){safe(file);fs.mkdirSync(path.dirname(file),{recursive:true});const tmp=file+'.label-'+crypto.randomUUID()+'.tmp';try{fs.writeFileSync(tmp,bytes,{flag:'wx',mode:0o600});fs.renameSync(tmp,file);}finally{if(fs.existsSync(tmp))fs.unlinkSync(tmp);}}
safe(root,'directory');if(!fs.existsSync(path.join(root,'package.json')))throw Error('NOT_AN_XCLIP_PROJECT');
const backupRoot=path.join(root,'.local-admin','auto-labels-mobile-installs');
const rollback=option('--rollback');
if(rollback){
 if(!/^[0-9TZA-Za-z-]{10,100}$/.test(rollback))throw Error('INVALID_BACKUP_NAME');
 const dir=path.join(backupRoot,rollback);safe(dir,'directory');const journalPath=path.join(dir,'journal.json');safe(journalPath);const journal=JSON.parse(fs.readFileSync(journalPath,'utf8'));
 if(journal.release!==token||!journal.complete||!Array.isArray(journal.files))throw Error('INVALID_BACKUP');
 const permitted=new Set([...Object.keys(manifest.files),'docs/XCLIP_UPDATE_HISTORY.md','docs/xclip-update-artifacts.json']);
 for(const entry of journal.files){if(!permitted.has(entry.path))throw Error('UNKNOWN_BACKUP_PATH');const file=path.join(root,entry.path);safe(file);if(!fs.existsSync(file)||hash(fs.readFileSync(file))!==entry.afterHash)throw Error('CHANGED_AFTER_INSTALL; rollback refused');if(entry.beforeExists){const b=path.join(dir,'before',entry.path);safe(b);if(hash(fs.readFileSync(b))!==entry.beforeHash)throw Error('BACKUP_HASH_MISMATCH');}}
 for(const entry of journal.files.slice().reverse()){const file=path.join(root,entry.path);if(entry.beforeExists)atomic(file,fs.readFileSync(path.join(dir,'before',entry.path)));else fs.unlinkSync(file);}
 console.log('XCLIP_AUTO_LABELS_MOBILE_ROLLBACK_OK; existing teachers/images/model retained');process.exit(0);
}
// All validation happens before any application file changes.
const writes=[];
for(const [relative,expected]of Object.entries(manifest.guards)){const file=path.join(root,relative);safe(file);if(!fs.existsSync(file)||hash(fs.readFileSync(file))!==expected)throw Error('UNKNOWN_DEPENDENCY_VERSION: '+relative+'; no application files changed');}
for(const [relative,spec]of Object.entries(manifest.files)){
 if(!(/^(app|lib|scripts)\/[A-Za-z0-9_./\[\]-]+$/.test(relative)||relative==='middleware.ts')||relative.split('/').includes('..'))throw Error('INVALID_MANIFEST_PATH');
 const source=path.join(here,'payload',relative),bytes=fs.readFileSync(source);if(hash(bytes)!==spec.after)throw Error('PAYLOAD_HASH_MISMATCH: '+relative);
 const target=path.join(root,relative);safe(target);const exists=fs.existsSync(target),old=exists?fs.readFileSync(target):null,oldHash=old?hash(old):null;
 if(oldHash===spec.after)continue;
 if(spec.before?oldHash!==spec.before:exists)throw Error('UNKNOWN_SOURCE_VERSION: '+relative+'; no application files changed');
 writes.push({path:relative,bytes,before:old});
}
const historyPath=path.join(root,'docs','XCLIP_UPDATE_HISTORY.md');safe(historyPath);const oldHistory=fs.existsSync(historyPath)?fs.readFileSync(historyPath):null;
if(!oldHistory||!oldHistory.toString('utf8').includes(token))writes.push({path:'docs/XCLIP_UPDATE_HISTORY.md',before:oldHistory,bytes:Buffer.from(manifest.historyEntry+'\n\n'+(oldHistory?.toString('utf8')??''),'utf8')});
const ledgerPath=path.join(root,'docs','xclip-update-artifacts.json');safe(ledgerPath);const oldLedger=fs.existsSync(ledgerPath)?fs.readFileSync(ledgerPath):null;
let previous=oldLedger?JSON.parse(oldLedger.toString('utf8').replace(/^\uFEFF/,'')):null;
if(previous?.release!==token)writes.push({path:'docs/xclip-update-artifacts.json',before:oldLedger,bytes:Buffer.from(JSON.stringify({release:token,scope:'local only',localApplied:true,productionApplied:null,databaseWrites:0,existingTierStateModified:false,files:manifest.files,guards:manifest.guards,previousRecords:previous},null,2)+'\n','utf8')});
if(!writes.length){console.log('XCLIP_AUTO_LABELS_MOBILE_ALREADY_INSTALLED; state unchanged');process.exit(0);}
const stamp=new Date().toISOString().replace(/[^0-9TZ]/g,'')+'-'+crypto.randomUUID();const dir=path.join(backupRoot,stamp);safe(dir,'directory');fs.mkdirSync(path.join(dir,'before'),{recursive:true,mode:0o700});
const journal={release:token,complete:false,files:writes.map(w=>({path:w.path,beforeExists:w.before!==null,beforeHash:w.before?hash(w.before):null,afterHash:hash(w.bytes)}))};
for(const w of writes)if(w.before){const file=path.join(dir,'before',w.path);fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,w.before,{flag:'wx',mode:0o600});}
fs.writeFileSync(path.join(dir,'journal.json'),JSON.stringify(journal,null,2),{mode:0o600});
const applied=[];
try{
 for(const w of writes){const file=path.join(root,w.path);safe(file);const current=fs.existsSync(file)?fs.readFileSync(file):null;if((current?hash(current):null)!==(w.before?hash(w.before):null))throw Error('SOURCE_CHANGED_DURING_INSTALL');atomic(file,w.bytes);applied.push(w);}
 journal.complete=true;fs.writeFileSync(path.join(dir,'journal.json'),JSON.stringify(journal,null,2),{mode:0o600});
}catch(e){for(const w of applied.reverse()){const file=path.join(root,w.path);safe(file);if(!fs.existsSync(file)||hash(fs.readFileSync(file))!==hash(w.bytes))throw Error('ROLLBACK_CONFLICT; backup='+dir);if(w.before)atomic(file,w.before);else fs.unlinkSync(file);}throw e;}
console.log('XCLIP_AUTO_LABELS_MOBILE_LOCAL_INSTALLED');console.log('BACKUP='+dir);console.log('OPEN=http://localhost:3004/label-publication');console.log('No DB/env/cron/provider changes; restart local management before use.');
