const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{createRequire}=require('node:module');
const project=path.resolve(process.argv[2]||''),payload=JSON.parse(fs.readFileSync(path.join(__dirname,'payload.json'),'utf8'));
if(!fs.existsSync(path.join(project,'.xclip-production-staging'))||fs.realpathSync(project)!==project)throw Error('ISOLATED_STAGING_REQUIRED; no files changed');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const ts=createRequire(path.join(project,'package.json'))('typescript');
const originals=new Map(), mismatches=[];
for(const [rel,text] of Object.entries(payload.files)){
 const target=path.resolve(project,rel);if(!target.startsWith(project+path.sep))throw Error('UNSAFE_PATH');
 for(let p=target;p!==project;p=path.dirname(p))if(fs.existsSync(p)&&fs.lstatSync(p).isSymbolicLink())throw Error('SYMLINK_REFUSED: '+rel);
 const old=fs.existsSync(target)?fs.readFileSync(target):null;
 if(!payload.acceptedHashes[rel]?.includes(hash(old??Buffer.alloc(0))))mismatches.push(rel+' '+hash(old??Buffer.alloc(0)));
 if(/\.tsx?$/.test(rel)){const sf=ts.createSourceFile(rel,text,ts.ScriptTarget.Latest,true,rel.endsWith('.tsx')?ts.ScriptKind.TSX:ts.ScriptKind.TS);if(sf.parseDiagnostics.length)throw Error('SYNTAX_FAILED: '+rel);}
 originals.set(target,old);
}
if(mismatches.length)throw Error('UNKNOWN_SOURCE_VERSION; public unchanged\n'+mismatches.join('\n'));
for(const [target,old] of originals){const now=fs.existsSync(target)?fs.readFileSync(target):null;if(old===null?now!==null:!now||!now.equals(old))throw Error('SOURCE_CHANGED; public unchanged');}
for(const [rel,text] of Object.entries(payload.files)){const target=path.join(project,rel);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,text);}
console.log('STAGED_FREE_CURATED_COLLECTION_INSTALLED; runtime unchanged');
