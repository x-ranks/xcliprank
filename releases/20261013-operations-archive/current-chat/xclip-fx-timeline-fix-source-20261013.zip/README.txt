Patch for confirmed fx-temporary-patrol-20261012. Use installers. Preserve quota, positions, removal/pause state. No env/private data. Actual API/DB sample pending.
