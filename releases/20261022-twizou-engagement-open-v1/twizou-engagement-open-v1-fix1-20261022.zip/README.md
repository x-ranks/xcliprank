# 動画オープン計測 v1 fix1

初回 `--apply` は本番切替前の `CANONICAL_TESTS_FAILED` で停止した。実ログは `test-public-pages.cjs` の `UNEXPECTED_IMPORT ../../components/PublicPostEngagement`。旧テストの描画用モックが追加部品を知らなかったため、モックと描画結果の確認を追加した。機能コード2ファイルは初回配布から変更なし。

保存済み本番ソースの隔離コピーで回帰52件、型チェック、Nextの本番ビルドを確認。Windowsのnode_modules junctionに起因するstandaloneコピー警告は出たが、本番ビルドは終了コード0。Linux本番stagingのビルド・公開確認は未実施。

このZIPを `/home/rbxfxmfd/twizou-engagement-open-v1-fix1-20261022.zip` にアップロードして実行：

```bash
unzip -q /home/rbxfxmfd/twizou-engagement-open-v1-fix1-20261022.zip -d /home/rbxfxmfd/twizou-engagement-open-v1-fix1-20261022
bash /home/rbxfxmfd/twizou-engagement-open-v1-fix1-20261022/apply-production-fix1.sh --check
bash /home/rbxfxmfd/twizou-engagement-open-v1-fix1-20261022/apply-production-fix1.sh --apply
```

成功表示は `TWIZOU_ENGAGEMENT_OPEN_V1_FIX1_DEPLOYMENT_COMPLETE`。staging検証・公開確認に失敗した場合は旧runtimeへ戻す。

ローカル機能コードは適用済み。今回のテストファイル1件のローカル適用も成功：バックアップ `C:\Projects\xcliprank-local-backups\twizou-engagement-open-test-fix-20261022T204639089`。
