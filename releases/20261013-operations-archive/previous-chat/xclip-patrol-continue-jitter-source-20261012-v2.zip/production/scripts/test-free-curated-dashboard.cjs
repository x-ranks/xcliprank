const fs=require('fs'),fsp=fs.promises,path=require('path'),os=require('os'),assert=require('assert/strict'),ts=require('typescript');
const root=path.resolve(__dirname,'..'),cache=new Map();let now=Date.now(),headCalls=0,activeHeads=0,maxHeads=0,failCounts=false,providerCalls=0;
let authors=[{x_author_id:'123',username:'test',name:'Test',is_curated:true,curated_status:'active',curated_expected_tier:'S',curated_last_post_id:'5000'}];
const db={from(table){const q={select(col,options){q.head=!!options?.head;return q},eq(){return q},limit(){return q},then(resolve,reject){
if(table==='authors')return Promise.resolve({data:authors,error:null}).then(resolve,reject);
headCalls++;activeHeads++;maxHeads=Math.max(maxHeads,activeHeads);return new Promise(r=>setImmediate(()=>{activeHeads--;r({data:null,count:failCounts?null:42,error:failCounts?{message:'db down'}:null})})).then(resolve,reject);}};return q}};
const substitutions={'lib/supabase-admin':{supabaseAdmin:()=>db},'lib/author-status-store':{readAuthorState:async()=>({cooldownUntil:0})},'lib/post-status-store':{readPostState:async()=>({cooldownUntil:0}),unavailableKeys:async()=>new Set()},
'lib/free-curated-publish':{publishFreeCandidates:async()=>({saved:0,promoted:0,duplicates:0,excluded:0})}};
function load(id){if(substitutions[id])return substitutions[id];if(cache.has(id))return cache.get(id).exports;const m={exports:{}};cache.set(id,m);const code=ts.transpileModule(fs.readFileSync(path.join(root,id+'.ts'),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,esModuleInterop:true}}).outputText;
new Function('require','module','exports',code)(n=>n.startsWith('.')?load(path.posix.normalize(path.posix.join(path.posix.dirname(id),n))):require(n),m,m.exports);return m.exports;}
const profile={id:'123',username:'test',name:'Test',expectedTier:'S'};
const status=id=>({type:'status',provider:'twitter',id:String(id),text:'test',author:{id:'123',screen_name:'test',protected:false},created_timestamp:Date.now()/1000-3600,possibly_sensitive:false,media:{videos:[{type:'video',format:'video/mp4',url:`https://video.twimg.com/${id}.mp4`}]}});
(async()=>{const tmp=await fsp.mkdtemp(path.join(os.tmpdir(),'xclip-dashboard-'));try{
const store=load('lib/free-curated-server-store'),scan=load('lib/free-curated-scan'),dashboard=load('lib/free-curated-dashboard');
let snapshot=await dashboard.freeCuratedDashboard({directory:tmp,database:db,now:()=>now,availabilityCooldown:async()=>now+3600000});assert.equal(snapshot.authors.length,1);assert.equal(snapshot.authors[0].databaseVideoTotal,42);assert.equal(snapshot.authors[0].metrics,null);assert(snapshot.authors[0].awaitingLegacyImport);assert.equal((await store.readScheduledFreeState(tmp)).authors.length,0);assert.equal(providerCalls,0);
const xstore=load('lib/x-curated-state'),metrics=load('lib/free-curated-metrics');
const s=store.freshFreeState();s.authors=[scan.newScheduledAuthor(profile,"free",now)];s.authors[0].metrics={...metrics.newFreeMetrics(now),lastOutcome:"success",lastFetched:2,lastNew:1,lastSaved:1,fetchedTotal:4};
s.authors[0].initialPending=true;await store.writeScheduledFreeState(s,tmp);
const x=xstore.freshXState();x.requests=24;x.rawPosts=120;x.reservations=Array.from({length:24},(_,i)=>({id:String(100+i),at:now}));x.positions['123']={sinceId:'5000',nextToken:'X_NEXT',endTime:new Date(now).toISOString(),startTime:null,newestId:'6000',warning:'coverage',checkedAt:now,savedTotal:1,rawTotal:2};await xstore.writeXState(x,tmp);
const stateBefore=await fsp.readFile(path.join(tmp,'state-v1.json')),xBefore=await fsp.readFile(path.join(tmp,'x-api-v1.json'));
snapshot=await dashboard.freeCuratedDashboard({directory:tmp,database:db,now:()=>now,availabilityCooldown:async()=>now+7*86400000});
assert.equal(snapshot.provider,'x_api');assert.equal(snapshot.dailyAuthorLimit,24);assert.equal(snapshot.dailyAuthorsUsed,24);assert.equal(snapshot.quotaNextAt,now+86400000);assert.equal(snapshot.nextPossibleAt,now+86400000);assert.equal(snapshot.xApiPostReadsTotal,120);assert(snapshot.authors[0].initialPending);assert(snapshot.authors[0].pendingPages);assert.equal(snapshot.authors[0].xApiWarning,'coverage');
const heads=headCalls;await dashboard.freeCuratedDashboard({directory:tmp,database:db,now:()=>now});assert.equal(headCalls,heads);assert.equal(snapshot.authors[0].metrics.fetchedTotal,4);assert.equal(snapshot.authors[0].databaseVideoTotal,42);
assert((await fsp.readFile(path.join(tmp,'state-v1.json'))).equals(stateBefore));assert((await fsp.readFile(path.join(tmp,'x-api-v1.json'))).equals(xBefore));
// Old provider cooldowns must not advertise a new X-wide pause or mutate history during a read.
s.cooldownUntil=now+10*86400000;x.cooldownUntil=now+10*86400000;await store.writeScheduledFreeState(s,tmp);await xstore.writeXState(x,tmp);
const cooldownBefore=await fsp.readFile(path.join(tmp,'x-api-v1.json'));
snapshot=await dashboard.freeCuratedDashboard({directory:tmp,database:db,now:()=>now});assert.equal(snapshot.collectorCooldownUntil,0);assert.equal(snapshot.nextPossibleAt,now+86400000);assert.equal(snapshot.errorPolicy,'continue_next_author');
assert((await fsp.readFile(path.join(tmp,'x-api-v1.json'))).equals(cooldownBefore));
now+=300001;failCounts=true;snapshot=await dashboard.freeCuratedDashboard({directory:tmp,database:db,now:()=>now,availabilityCooldown:async()=>0});assert.equal(snapshot.authors[0].databaseVideoTotal,null);
failCounts=false;authors=Array.from({length:20},(_,i)=>({...authors[0],x_author_id:String(200+i),username:'test'+i}));now+=300001;snapshot=await dashboard.freeCuratedDashboard({directory:tmp,database:db,now:()=>now,availabilityCooldown:async()=>0});assert(maxHeads<=4);assert.equal(snapshot.authors.length,21);
s.authors[0].metrics.lastOutcome='invalid';await store.writeScheduledFreeState(s,tmp);const bytes=await fsp.readFile(path.join(tmp,'state-v1.json'));await assert.rejects(store.readScheduledFreeState(tmp),e=>e.status===503);assert((await fsp.readFile(path.join(tmp,'state-v1.json'))).equals(bytes));
console.log('PASS HYBRID DASHBOARD: read-only legacy preview; DB totals/cache/concurrency/errors; X quota/window and continuation; initial pending; metrics; availability Fx cooldown does not stop X; corrupt state refused; no provider requests.');
}finally{await fsp.rm(tmp,{recursive:true,force:true})}})().catch(e=>{console.error(e);process.exitCode=1});
