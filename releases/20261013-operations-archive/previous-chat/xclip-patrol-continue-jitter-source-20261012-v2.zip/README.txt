v2 supersedes v1. Distinct production/local patch sets; requires unified-authors. Existing legacy monitor is not a replacement target. Use installers. No secrets or runtime state included.
