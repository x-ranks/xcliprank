'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),ts=require('typescript');
const {NextRequest}=require('next/server');
const file=path.join(__dirname,'../middleware.ts'),loaded={exports:{}};
const js=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
new Function('require','module','exports',js)(require,loaded,loaded.exports);
const previous=process.env.NODE_ENV;process.env.NODE_ENV='production';
try{
 for(const path of ['/browse','/browse?page=2','/accounts','/accounts?page=2','/tags','/tags/%E7%84%A1%E4%BF%AE%E6%AD%A3','/api/manual-ranking']){
  const response=loaded.exports.middleware(new NextRequest('https://xcliprank.com'+path));
  assert.equal(response.status,200,path);
 }
 assert.equal(loaded.exports.middleware(new NextRequest('https://xcliprank.com/manual-ranking')).status,404);
 console.log('PASS SEO MIDDLEWARE: hubs and protected admin API reach application; public admin page remains blocked');
}finally{if(previous===undefined)delete process.env.NODE_ENV;else process.env.NODE_ENV=previous;}
