Distinct production/local patch sets. Use installers. This is not a full application. No environment or registration files included.
