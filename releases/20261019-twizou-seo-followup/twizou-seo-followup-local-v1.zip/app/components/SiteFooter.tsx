import Link from "next/link";

export default function SiteFooter() {
  return (
    <footer>
      <p className="site-footer-age">18歳未満の方は利用できません。</p>
      <p>
        twizouは公開投稿と管理者が登録した動画URLのランキングを提供します。再生できる動画は元の配信元からお使いの端末へ直接読み込まれます。twizouでは動画ファイルの保管・再アップロードは行っていません。X動画の保存補助機能も提供します。
      </p>
      <p>
        違法または権利侵害と思われる投稿は、<Link href="/removal-request">削除要請フォーム</Link>からお知らせください。
      </p>
      <nav className="site-footer-links" aria-label="サイト情報">
        <Link href="/browse">動画一覧</Link>
        <Link href="/accounts">投稿者一覧</Link>
        <Link href="/tags">ラベル一覧</Link>
        <Link href="/privacy">プライバシー</Link>
        <Link href="/terms">利用規約</Link>
        <Link href="/copyright">著作権・削除方針</Link>
        <Link href="/advertising-disclosure">広告・PR表記</Link>
        <Link href="/contact">お問い合わせ</Link>
      </nav>
    </footer>
  );
}

