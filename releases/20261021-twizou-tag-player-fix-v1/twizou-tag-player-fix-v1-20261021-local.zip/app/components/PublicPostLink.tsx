"use client";
import Link from "next/link";
import { useEffect, useState, type ReactNode, type CSSProperties } from "react";
import { publicDetailHref, safePublicReturn, returnPosition, RETURN_STORAGE_KEY } from "../../lib/public-return-navigation";
export default function PublicPostLink({ id, returnTo = "/", children, style, ariaLabel, nativeNavigation = false }: { id: string; returnTo?: string; children: ReactNode; style?: CSSProperties; ariaLabel?: string; nativeNavigation?: boolean }) {
  const [from, setFrom] = useState(safePublicReturn(returnTo) ?? "/");
  useEffect(() => {
    const u = new URL(window.location.href);
    setFrom(safePublicReturn(u.pathname + u.search) ?? safePublicReturn(u.searchParams.get("from")) ?? safePublicReturn(returnTo) ?? "/");
  }, [returnTo, id]);
  function remember() {
    try {
      const here = new URL(window.location.href), list = safePublicReturn(here.pathname + here.search);
      if (list) sessionStorage.setItem(RETURN_STORAGE_KEY, JSON.stringify({ version: 1, from: list, postId: id, y: window.scrollY, at: Date.now(), restore: false }));
      else { const previous = returnPosition(sessionStorage.getItem(RETURN_STORAGE_KEY)); if (previous && previous.from === from) sessionStorage.setItem(RETURN_STORAGE_KEY, JSON.stringify({ ...previous, at: Date.now() })); }
    } catch { /* Navigation remains usable with storage disabled. */ }
  }
  const href = publicDetailHref(id, from);
  if (nativeNavigation) return <a href={href} onClick={remember} style={style} aria-label={ariaLabel}>{children}</a>;
  return <Link href={href} prefetch={false} onClick={remember} style={style} aria-label={ariaLabel}>{children}</Link>;
}
