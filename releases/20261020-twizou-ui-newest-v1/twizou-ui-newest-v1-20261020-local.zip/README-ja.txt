twizou ローカル詳細ページ表示更新 2026-10-20
状態: 作成・隔離検証済み。実際のC:/Projects/xcliprankへの適用は未実施。
開発サーバーを停止し、node apply-local.cjs --check / node apply-local.cjs --apply の順に実行してください。
成功時のLOCAL_BACKUPを保持してください。戻す場合は node apply-local.cjs --rollback <LOCAL_BACKUP> です。
新着順位の処理は本番API側で行います。ローカルのランキングAPIは本番版を読みます。
