# twizou SEO 追加実装・個別URL登録 本番適用

この配布物は **未適用** です。既存の twizou SEO v1 fix2 適用済み環境だけを対象にします。`--check` は読み取り専用で、42ファイルの現行ハッシュと配布物ハッシュ、既存の監視ワーカー接続を確認します。`--apply` は隔離ディレクトリでテスト・型検査・ビルドを行い、成功したときだけ本番ランタイムを切り替えます。切替後の公開URL確認に失敗した場合は、旧ランタイムへ自動復元します。Cron と監視ラッパーは変更しません。

## 実行

ZIPを `/home/rbxfxmfd/twizou-seo-followup-v1.zip` にアップロードしてから、次を順に実行してください。

```bash
mkdir -p /home/rbxfxmfd/twizou-seo-followup-v1-20261019
unzip -q /home/rbxfxmfd/twizou-seo-followup-v1.zip -d /home/rbxfxmfd/twizou-seo-followup-v1-20261019
bash /home/rbxfxmfd/twizou-seo-followup-v1-20261019/apply-production.sh --check
bash /home/rbxfxmfd/twizou-seo-followup-v1-20261019/apply-production.sh --apply
```

`--apply` の成功表示は `TWIZOU_SEO_FOLLOWUP_V1_DEPLOYMENT_COMPLETE` です。`PREVIOUS_RUNTIME_BACKUP=` と `NEW_BUILD_ID=` を含む出力を共有してください。失敗した場合は再実行せず、表示された `STAGING_DIRECTORY` と失敗メッセージを共有してください。秘密情報を含み得る staging log は公開しないでください。

公開後は sitemap、動画ページ、新しい一覧3種、週間ランキング、reels、存在しない動画の404メタをスクリプトが確認します。サーバーデータに基づく実際のインデックス数・全URL到達率は適用後に測定します。

個別URL登録データはサーバーの `~/.xclip-manual-ranking` に保存されます。ランタイムをロールバックしても管理データは残るため、登録前後で状態を確認してください。ローカル管理画面から操作する前に本番適用を済ませてください。
