import type { Metadata } from "next";
import Link from "next/link";
import { readPublicLabels } from "../../lib/public-video-server";
import { tagHref } from "../../lib/public-video-core";
import { isIndexable } from "../../lib/indexability";
export const dynamic = "force-dynamic";
export async function generateMetadata(): Promise<Metadata> {
  const labels = await readPublicLabels();
  return { title: "ラベル一覧", robots: { index: isIndexable({ type: "tag-hub", activeTags: labels.length }), follow: true },
    alternates: { canonical: "/tags" }, description: "twizouの動画ラベル一覧です。",
    openGraph: { title: "ラベル一覧｜twizou", url: "/tags" } };
}
export default async function TagsPage() {
  const labels = await readPublicLabels();
  return <main style={{ maxWidth: 900, margin: "0 auto", padding: 24 }}><Link href="/">新着ランキング</Link>
    <h1>ラベル一覧</h1><ul>{labels.map(label => <li key={label.id}><Link href={tagHref({ ...label, active: true })}>{label.name}</Link>（{label.count}件）</li>)}</ul></main>;
}
