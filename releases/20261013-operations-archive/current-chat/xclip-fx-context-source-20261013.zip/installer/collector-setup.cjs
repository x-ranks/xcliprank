const fs=require('fs'),path=require('path'),cp=require('child_process'),crypto=require('crypto');
const [action,account,stage]=process.argv.slice(2),backup=path.join(stage,'collector.before.json');
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const definitions=[
 {name:'free-collector.sh',target:path.join(account,'xclip-free-curated-collector.sh'),folder:path.join(account,'.xclip-free-curated'),marker:'# xclip-free-curated-collector-v1',schedule:'47 */3 * * *',log:'collector.log'},
 {name:'monitor-jitter.sh',target:path.join(account,'xclip-author-monitor-jitter.sh'),legacy:path.join(account,'xclip-author-monitor.sh'),folder:path.join(account,'.xclip-author-status'),marker:'# xclip-free-author-monitor-v1',schedule:'17 */3 * * *',log:'monitor.log'}
];
const known=JSON.parse(fs.readFileSync(path.join(__dirname,'scheduler-accepted.json'),'utf8'));
const proposed=d=>fs.readFileSync(path.join(__dirname,d.name),'utf8');
const line=(d,target=d.target)=>`${d.schedule} /bin/bash ${target} >> ${d.folder}/${d.log} 2>&1 ${d.marker}`;
function cron(){const r=cp.spawnSync('crontab',['-l'],{encoding:'utf8'});if(r.status===0)return r.stdout;if(r.status===1&&/no crontab/i.test(r.stderr))return '';throw Error('CRONTAB_READ_FAILED');}
function writeCron(value){cp.execFileSync('crontab',['-'],{input:value,stdio:['pipe','pipe','pipe']});}
function safeFile(file,mode){const s=fs.lstatSync(file);if(!s.isFile()||s.uid!==process.getuid()||(mode!=null&&(s.mode&0o777)!==mode))throw Error('SCHEDULER_UNSAFE_FILE: '+path.basename(file));}
function install(file,text,mode=0o700){if(fs.existsSync(file))safeFile(file);const temp=file+'.'+process.pid;try{fs.writeFileSync(temp,text,{flag:'wx',mode});fs.chmodSync(temp,mode);fs.renameSync(temp,file);}finally{if(fs.existsSync(temp))fs.unlinkSync(temp);}}
function verifyDependencies(saved){for(const item of saved.dependencies){safeFile(item.path);if(hash(fs.readFileSync(item.path))!==item.sha256)throw Error('LEGACY_MONITOR_CHANGED_DURING_STAGING; existing script preserved');}}
if(action==='prepare'){
 cp.execFileSync('sh',['-c','command -v flock >/dev/null && command -v crontab >/dev/null']);
 const before=cron(),scripts=[],dependencies=[];
 for(const d of definitions){
  if(fs.existsSync(d.folder)){const s=fs.lstatSync(d.folder);if(!s.isDirectory()||s.uid!==process.getuid()||(s.mode&0o077)!==0)throw Error('SCHEDULER_STATE_DIRECTORY_UNSAFE');}
  if(fs.existsSync(d.target)){safeFile(d.target);const digest=hash(fs.readFileSync(d.target));if(!known[d.name].includes(digest))throw Error('UNKNOWN_SCHEDULER_SCRIPT; file='+path.basename(d.target)+'; sha256='+digest+'; existing settings preserved');}
  // The existing monitor is a dependency, never a replacement target. Preserve arbitrary prior changes.
  if(d.legacy){if(!fs.existsSync(d.legacy))throw Error('LEGACY_MONITOR_MISSING; existing settings preserved');safeFile(d.legacy);dependencies.push({path:d.legacy,sha256:hash(fs.readFileSync(d.legacy))});}
  const related=before.split('\n').filter(s=>s.trim()&&!s.trimStart().startsWith('#')&&(s.includes(d.target)||(d.legacy&&s.includes(d.legacy))||s.trimEnd().endsWith(d.marker)));
  if(related.length>1||related.some(s=>s.trim()!==line(d)&&(!d.legacy||s.trim()!==line(d,d.legacy))))throw Error('UNKNOWN_OR_DUPLICATE_SCHEDULE; file='+path.basename(d.target)+'; existing settings preserved');
  scripts.push({name:d.name,target:d.target,before:fs.existsSync(d.target)?fs.readFileSync(d.target,'utf8'):null,mode:fs.existsSync(d.target)?fs.statSync(d.target).mode&0o777:null});
 }
 const next=before.split('\n').filter(s=>!definitions.some(d=>s.trimEnd().endsWith(d.marker))).join('\n').replace(/\n*$/,'\n')+definitions.map(d=>line(d)).join('\n')+'\n';
 fs.writeFileSync(backup,JSON.stringify({before,next,scripts,dependencies}),{flag:'wx',mode:0o600});console.log('PATROL_SCHEDULERS_V2_PREPARED; cron unchanged; legacy monitor retained');
}else{
 const saved=JSON.parse(fs.readFileSync(backup,'utf8'));
 if(action==='apply'){
  if(cron()!==saved.before)throw Error('CRONTAB_CHANGED_DURING_STAGING');verifyDependencies(saved);
  for(const s of saved.scripts){if((fs.existsSync(s.target)?fs.readFileSync(s.target,'utf8'):null)!==s.before)throw Error('SCHEDULER_SCRIPT_CHANGED_DURING_STAGING');}
  for(const d of definitions){fs.mkdirSync(d.folder,{recursive:true,mode:0o700});install(d.target,proposed(d));}writeCron(saved.next);
  console.log('PATROL_SCHEDULERS_V2_INSTALLED; COLLECTION_ERRORS=continue; failed_author_counts=1; rolling24h=24; LEGACY_MONITOR=UNCHANGED; FX_START_JITTER=0_240_SECONDS; FX_REQUEST_JITTER=8_20_SECONDS');
 }else if(action==='restore'){
  const current=cron();if(current===saved.next)writeCron(saved.before);else if(current!==saved.before)throw Error('NEWER_CRONTAB_PRESERVED');
  for(const s of saved.scripts){const d=definitions.find(d=>d.name===s.name);if(!d||d.target!==s.target)throw Error('INVALID_SCHEDULER_BACKUP');const current=fs.existsSync(s.target)?fs.readFileSync(s.target,'utf8'):null;
   if(current===proposed(d)){if(s.before===null)fs.unlinkSync(s.target);else install(s.target,s.before,s.mode);}else if(current!==s.before)throw Error('NEWER_SCHEDULER_SCRIPT_PRESERVED');}
  console.log('PATROL_SCHEDULERS_V2_RESTORED; legacy monitor retained');
 }else if(action==='verify'){
  if(cron()!==saved.next)throw Error('PATROL_CRON_VERIFY_FAILED');verifyDependencies(saved);for(const d of definitions){safeFile(d.target,0o700);if(fs.readFileSync(d.target,'utf8')!==proposed(d))throw Error('PATROL_SCRIPT_VERIFY_FAILED');}
  console.log('PATROL_SCHEDULERS_V2_CRON_OK; legacy monitor retained');
 }else throw Error('UNKNOWN_SCHEDULER_ACTION');
}
