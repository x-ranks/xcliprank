const assert=require('assert/strict');
function canonicalHrefs(html) {
  const decode=s=>s.replace(/&amp;/g,'&').replace(/&#(?:0*38|x0*26);/gi,'&').replace(/&quot;/g,'"');
  const result=[];
  const markup=html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,'').replace(/<!--[\s\S]*?-->/g,'');
  for(const match of markup.matchAll(/<link\b[^>]*>/gi)) {
    const attrs={};for(const item of match[0].matchAll(/([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g))attrs[item[1].toLowerCase()]=decode(item[2]??item[3]);
    if(attrs.rel?.toLowerCase().split(/\s+/).includes('canonical'))result.push(attrs.href??'');
  }
  return result;
}
function assertCanonical(html,page) {
  const expected='https://xcliprank.com'+(page===1?'/':'/?page='+page),hrefs=canonicalHrefs(html);
  if(hrefs.length!==1||hrefs[0]!==expected) {
    // Print public URL structure only; never unknown query values or credentials.
    const safe=hrefs.map(href=>{try{const u=new URL(href);return {expectedOrigin:u.origin==='https://xcliprank.com',rootPath:u.pathname==='/',page:u.searchParams.get('page')?.match(/^\d{1,2}$/)?.[0]??null,hasOtherQuery:[...u.searchParams.keys()].some(k=>k!=='page'),hasCredentials:!!(u.username||u.password)};}catch{return {invalid:true};}});
    throw Error('CANONICAL_MISMATCH expected='+expected+' actual='+JSON.stringify(safe));
  }
}
module.exports={canonicalHrefs,assertCanonical};
if(require.main===module){
 const base=process.env.BASE;
 if(!(base==='https://xcliprank.com'||/^http:\/\/127\.0\.0\.1:\d+$/.test(base)))throw Error('INVALID_VERIFY_BASE');
 const tag=base.startsWith('https:')?'PUBLIC_':'STAGING_';
 async function get(p){const r=await fetch(base+p,{cache:'no-store',redirect:'manual',signal:AbortSignal.timeout(60000)});if(!r.ok)throw Error('HTTP_'+r.status+' '+p.split('&edition=')[0]);return r;}
 (async()=>{
  const headers={Authorization:'Bearer '+process.env.CRON_SECRET};
  const config=await fetch(base+'/api/free-curated-sync',{headers,redirect:'error',signal:AbortSignal.timeout(60000)});assert.equal(config.status,200);
  const feature=await config.json();assert(feature.ok&&feature.registrationRecoveryVersion===1&&feature.registrationAuthorLimit===1000&&feature.dailyAuthorLimit===24&&feature.batchLimit===8&&feature.scheduledProvider==='fxtwitter');
  const databaseHost=new URL(process.env.SUPABASE_URL??process.env.NEXT_PUBLIC_SUPABASE_URL).hostname;
  const status=await fetch(base+'/api/free-curated-sync',{method:'POST',headers:{...headers,'Content-Type':'application/json'},body:JSON.stringify({action:'status',databaseHost}),redirect:'error',signal:AbortSignal.timeout(60000)});assert.equal(status.status,200);
  const state=await status.json();assert(state.ok&&state.registrationRecoveryVersion===1&&state.registrationAuthorLimit===1000&&Array.isArray(state.state.authors)&&state.state.authors.length<=1000);
  console.log(tag+'REGISTRATION_RECOVERY1000_OK; existingAuthors='+state.state.authors.length+'; status read only; provider requests0');
  const all=await (await get('/api/rankings?range=trending')).json();
  assert(all.ok&&all.targetPostCount===500&&all.count>0&&all.count<=500&&all.edition&&all.pagination.totalPages<=10);
  const edition=encodeURIComponent(all.edition);
  const [daily,weekly,weeklyBase]=await Promise.all(['daily','weekly','weekly&visual=0'].map(r=>get('/api/rankings?range='+r+'&edition='+edition).then(r=>r.json())));
  const reserved=new Set([...daily.data,...weekly.data,...weeklyBase.data].map(p=>p.x_post_id));
  assert(all.data.every(p=>!reserved.has(p.x_post_id)));assert.equal(new Set(all.data.map(p=>p.x_post_id)).size,all.count);
  const seen=new Set();
  for(let p=1;p<=all.pagination.totalPages;p++){
   const page=await (await get('/api/rankings?range=trending&page='+p+'&edition='+edition)).json();
   assert(page.ok&&page.pagination.page===p&&page.data.length<=50&&page.edition===all.edition);
   for(const row of page.data){assert(!seen.has(row.x_post_id)&&!reserved.has(row.x_post_id));seen.add(row.x_post_id);assert(row.ranking_position>(p-1)*50&&row.ranking_position<=p*50);}
  }
  const root=await (await get('/?page=1&edition='+edition)).text();
  assert(root.includes('ranking-pagination')&&root.includes('application/ld+json'));assertCanonical(root,1);
  if(all.pagination.totalPages>1){const second=await (await get('/?page=2&edition='+edition)).text();assertCanonical(second,2);assert(root.includes('さらに表示（次の50件）'));}
  for(const p of ['/ranking/daily?edition='+edition,'/ranking/weekly?edition='+edition,'/reels','/download','/download-policy'])await (await get(p)).body?.cancel();
  const invalid=await fetch(base+'/?page=11',{redirect:'manual',signal:AbortSignal.timeout(60000)});assert.equal(invalid.status,404);await invalid.body?.cancel();
  for(const p of ['/curated-manager','/availability-monitor','/fxtwitter-authors']){const r=await fetch(base+p,{redirect:'manual',signal:AbortSignal.timeout(60000)});assert.equal(r.status,404);await r.body?.cancel();}
  console.log(tag+'NEWEST500_V2_VERIFIED; target500 actual='+all.count+' pages='+all.pagination.totalPages+'; daily/weekly overlap0; unique pages; exact canonical1/2; SSR; no provider collection requests');
 })().catch(e=>{console.error(tag+'NEWEST500_V2_VERIFICATION_FAILED: '+e.message);process.exitCode=1;});
}
