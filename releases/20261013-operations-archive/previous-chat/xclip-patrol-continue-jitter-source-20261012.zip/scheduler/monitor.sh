#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
ACCOUNT=/home/rbxfxmfd
NODE="$ACCOUNT/.local/node/node-v22.23.2-linux-x64/bin/node"
export PATH="$(dirname "$NODE"):$PATH"
[[ "$#" -le 1 && ( "${1:-}" == "" || "${1:-}" == "--check-runtime" ) ]] || { echo 'AUTHOR_MONITOR_INVALID_ARGUMENT'; exit 2; }
# Start jitter is below the existing five-minute batch tolerance. Sleep before taking the worker lock.
if [[ "${1:-}" != "--check-runtime" ]]; then
 JITTER_SECONDS=$("$NODE" -e 'console.log(require("node:crypto").randomInt(0,241))')
 [[ "$JITTER_SECONDS" =~ ^[0-9]+$ && "$JITTER_SECONDS" -le 240 ]] || { echo 'AUTHOR_MONITOR_INVALID_JITTER'; exit 1; }
 sleep "$JITTER_SECONDS"
fi
exec 9> "$ACCOUNT/.xclip-author-monitor.lock"
flock -n 9 || exit 0
if ! LOCATIONS_TEXT=$(ACCOUNT="$ACCOUNT" "$NODE" <<'JS'
const fs=require('fs'),path=require('path'),a=process.env.ACCOUNT;
const ht=fs.readFileSync(path.join(a,'public_html/.htaccess'),'utf8');
const roots=[...ht.matchAll(/^\s*PassengerAppRoot\s+"([^"]+)"\s*$/gm)];
if(roots.length!==1||!/^\/home\/rbxfxmfd\/xclip-[^\r\n]+\/runtime$/.test(roots[0][1]))throw Error('UNEXPECTED_RUNTIME');
const runtime=roots[0][1],source=fs.readFileSync(path.join(runtime,'DEPLOY_SOURCE'),'utf8').trim();
if(!/^\/home\/rbxfxmfd\/xclip-[^\r\n]+\/source$/.test(source)||
 fs.readFileSync(path.join(source,'.next/BUILD_ID'),'utf8').trim()!==fs.readFileSync(path.join(runtime,'.next/BUILD_ID'),'utf8').trim())throw Error('MONITOR_SOURCE_MISMATCH');
console.log(runtime);console.log(source);
JS
); then
 echo 'AUTHOR_MONITOR_RUNTIME_LOOKUP_FAILED; no scan started'
 exit 1
fi
readarray -t LOCATIONS <<< "$LOCATIONS_TEXT"
unset LOCATIONS_TEXT
[[ "${#LOCATIONS[@]}" == 2 ]] || { echo 'AUTHOR_MONITOR_RUNTIME_NOT_FOUND'; exit 1; }
RUNTIME="${LOCATIONS[0]}"
SOURCE="${LOCATIONS[1]}"
if [[ "${1:-}" == "--check-runtime" ]]; then
 echo 'AUTHOR_MONITOR_RUNTIME_CHECK_OK; no API requests'
 exit 0
fi
[[ -f "$SOURCE/scripts/scan-author-status.cjs" ]] || { echo 'AUTHOR_MONITOR_NOT_SUPPORTED_BY_RUNTIME'; exit 1; }
# Keep the log bounded. The directory is private and persists outside runtime.
[[ ! -f "$ACCOUNT/.xclip-author-status/monitor.log" || "$(stat -c %s "$ACCOUNT/.xclip-author-status/monitor.log")" -lt 2097152 ]] ||
 mv "$ACCOUNT/.xclip-author-status/monitor.log" "$ACCOUNT/.xclip-author-status/monitor.log.prev"
cd "$SOURCE"
exec "$NODE" --env-file="$RUNTIME/.env.production" scripts/scan-author-status.cjs
