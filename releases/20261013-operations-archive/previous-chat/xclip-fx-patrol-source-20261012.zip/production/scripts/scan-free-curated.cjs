const fs=require('fs'),path=require('path'),{createRequire}=require('module');
const root=path.resolve(__dirname,'..'),ts=createRequire(path.join(root,'package.json'))('typescript');
require.extensions['.ts']=(mod,file)=>mod._compile(ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,esModuleInterop:true}}).outputText,file);
require('../lib/free-curated-scan.ts').scanFreeCurated().then(stats=>console.log(JSON.stringify({...stats,at:new Date().toISOString()})))
 .catch(()=>{console.error('FX_CURATED_SCAN_FAILED; watermark/quota preserved; inspect state/DB/connectivity');process.exitCode=1;});
