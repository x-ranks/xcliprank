const assert=require('assert/strict');
const base=process.env.BASE;
if(!(base==='https://xcliprank.com'||/^http:\/\/127\.0\.0\.1:\d+$/.test(base)))throw Error('INVALID_VERIFY_BASE');
const tag=base.startsWith('https:')?'PUBLIC_':'STAGING_';
async function get(p){const r=await fetch(base+p,{cache:'no-store',redirect:'manual',signal:AbortSignal.timeout(60000)});if(!r.ok)throw Error('HTTP_'+r.status+' '+p.split('&edition=')[0]);return r;}
(async()=>{
 const all=await (await get('/api/rankings?range=trending')).json();
 assert(all.ok&&all.targetPostCount===500&&all.count>0&&all.count<=500&&all.edition&&all.pagination.totalPages<=10);
 const edition=encodeURIComponent(all.edition);
 const [daily,weekly,weeklyBase]=await Promise.all(['daily','weekly','weekly&visual=0'].map(r=>get('/api/rankings?range='+r+'&edition='+edition).then(r=>r.json())));
 const reserved=new Set([...daily.data,...weekly.data,...weeklyBase.data].map(p=>p.x_post_id));
 assert(all.data.every(p=>!reserved.has(p.x_post_id)));assert.equal(new Set(all.data.map(p=>p.x_post_id)).size,all.count);
 const seen=new Set();
 for(let p=1;p<=all.pagination.totalPages;p++){
  const page=await (await get('/api/rankings?range=trending&page='+p+'&edition='+edition)).json();
  assert(page.ok&&page.pagination.page===p&&page.data.length<=50&&page.edition===all.edition);
  for(const row of page.data){assert(!seen.has(row.x_post_id)&&!reserved.has(row.x_post_id));seen.add(row.x_post_id);assert(row.ranking_position>(p-1)*50&&row.ranking_position<=p*50);}
 }
 const root=await (await get('/?page=1&edition='+edition)).text();
 assert(root.includes('ranking-pagination')&&root.includes('application/ld+json'));
 if(all.pagination.totalPages>1){const second=await (await get('/?page=2&edition='+edition)).text();assert(second.includes('rel="canonical"')&&second.includes('href="https://xcliprank.com/?page=2"'));assert(root.includes('さらに表示（次の50件）'));}
 for(const p of ['/ranking/daily?edition='+edition,'/ranking/weekly?edition='+edition,'/reels','/download','/download-policy'])await (await get(p)).body?.cancel();
 const invalid=await fetch(base+'/?page=11',{redirect:'manual',signal:AbortSignal.timeout(60000)});assert.equal(invalid.status,404);await invalid.body?.cancel();
 for(const p of ['/curated-manager','/availability-monitor','/fxtwitter-authors']){const r=await fetch(base+p,{redirect:'manual',signal:AbortSignal.timeout(60000)});assert.equal(r.status,404);await r.body?.cancel();}
 console.log(tag+'NEWEST500_VERIFIED; target500 actual='+all.count+' pages='+all.pagination.totalPages+'; daily/weekly overlap0; unique pages; SSR/canonical; public routes; no provider collection requests');
})().catch(e=>{console.error(tag+'NEWEST500_VERIFICATION_FAILED: '+e.message);process.exitCode=1;});
