import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import PublicVideoCards from "../../components/PublicVideoCards";
import { PUBLIC_SITE } from "../../../lib/public-video-core";
import { readPublicAccount } from "../../../lib/public-video-server";
import { SITE_NAME } from "../../../lib/seo";
export const dynamic = "force-dynamic";
type Props = { params: Promise<{ key: string }>; searchParams?: Promise<{ page?: string | string[] }> };
async function readPage(props: Props) {
  const { key } = await props.params, search = await props.searchParams;
  const raw = search?.page;
  if (raw !== undefined && (typeof raw !== "string" || !/^[1-9]\d{0,3}$/.test(raw))) notFound();
  const page = raw === undefined ? 1 : Number(raw);
  return { d: await readPublicAccount(key, page), page };
}
export async function generateMetadata(props: Props): Promise<Metadata> {
  const { d, page } = await readPage(props);
  if (!d) return {};
  const canonical = `${PUBLIC_SITE}/accounts/${encodeURIComponent(d.canonicalKey)}${page > 1 ? `?page=${page}` : ""}`;
  const title = `${d.name}の動画｜${SITE_NAME}`;
  const example = Array.from(d.videos.map(v => v.text?.replace(/https?:\/\/t\.co\/\S+/gi, "").replace(/\s+/g, " ").trim()).find(Boolean) ?? "").slice(0, 55).join("");
  const description = `${d.name}の掲載可能な動画${d.videos.length}件を紹介します。${example ? `内容例：${example}。` : ""}投稿と関連動画を確認できます。`;
  const images = d.videos.find(v => v.posterUrl)?.posterUrl;
  return { title: { absolute: title }, description, alternates: { canonical }, robots: { index: d.index, follow: true },
    openGraph: { type: "website", title, description, url: canonical, ...(images ? { images: [images] } : {}) },
    twitter: { card: "summary_large_image", title, description, ...(images ? { images: [images] } : {}) } };
}
export default async function AccountPage(props: Props) {
  const { d, page } = await readPage(props); if (!d) notFound();
  const base = `/accounts/${encodeURIComponent(d.canonicalKey)}`;
  return <main style={{ maxWidth: 1120, margin: "0 auto", padding: 24 }}><Link href="/accounts">投稿者一覧</Link><h1>{d.name}の動画</h1>
    <p>{d.name}の掲載可能な動画{d.totalCount}件のうち、{page} / {d.totalPages}ページを表示しています。</p><PublicVideoCards videos={d.videos} />
    <nav aria-label="投稿者の動画ページ" style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
      {Array.from({ length: d.totalPages }, (_, i) => <Link key={i} href={i === 0 ? base : `${base}?page=${i + 1}`}
        aria-current={i + 1 === page ? "page" : undefined}>{i + 1}</Link>)}
    </nav></main>;
}
