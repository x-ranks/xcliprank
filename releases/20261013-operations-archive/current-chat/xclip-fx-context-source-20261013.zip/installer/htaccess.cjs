const fs=require('node:fs'),path=require('node:path');
const [action,target,folder]=process.argv.slice(2);
const check=()=>{const s=fs.lstatSync(target);if(!s.isFile()||s.uid!==process.getuid()||(s.mode&0o777)!==0o644)throw Error('HTACCESS_MUST_BE_OWNED_REGULAR_FILE_MODE_644');};
check();
const beforePath=path.join(folder,'htaccess.before'),afterPath=path.join(folder,'htaccess.after');
function atomic(bytes){check();const temp=target+'.xclip-stream-'+process.pid;let fd;try{fd=fs.openSync(temp,'wx',0o600);fs.writeFileSync(fd,bytes);fs.fchmodSync(fd,0o644);fs.fsyncSync(fd);fs.closeSync(fd);fd=undefined;if((fs.statSync(temp).mode&0o777)!==0o644)throw Error('TEMP_MODE_MISMATCH');fs.renameSync(temp,target);check();if(!fs.readFileSync(target).equals(bytes))throw Error('HTACCESS_WRITE_MISMATCH');}finally{if(fd!==undefined)fs.closeSync(fd);if(fs.existsSync(temp))fs.unlinkSync(temp);}}
if(action==='prepare'){
 const before=fs.readFileSync(target,'utf8');let current=before;
 for(const[guard,extra,required]of [
  ['RewriteCond %{REQUEST_METHOD} !^(GET|HEAD)$ [NC]',['video-resolve','free-curated-sync'],['engagement','contact-requests','removal-requests','collect-curated-author']],
  ['RewriteCond %{REQUEST_URI} ^/api/ [NC]',['video-resolve','video-download','video-playback-url','free-curated-sync'],['rankings','reels','video','engagement','engagement-stats']]
 ]){
  let matches=0;
  const pattern=/^(\s*RewriteCond\s+%\{REQUEST_URI\}\s+!\^\/api\/\()([a-z0-9|\-]+)(\)\(\/\|\$\)\s+\[NC\][ \t]*)$/gm;
  current=current.replace(pattern,(line,start,names,end,offset)=>{
   const previous=current.slice(0,offset).trimEnd().split(/\r?\n/).at(-1)?.trim();
   if(previous!==guard)return line;
   const following=current.slice(offset+line.length).trimStart().split(/\r?\n/)[0]?.trim();
   const list=names.split('|');
   if(following!=='RewriteRule ^ - [F,L]'||required.some(n=>!list.includes(n)))throw Error('UNEXPECTED_API_ALLOWLIST');
   matches++;return start+[...list,...extra.filter(n=>!list.includes(n))].join('|')+end;
  });
  if(matches!==1)throw Error('ALLOWLIST_MATCH_COUNT_'+matches);
 }
 fs.writeFileSync(beforePath,before,{flag:'wx',mode:0o600});fs.writeFileSync(afterPath,current,{flag:'wx',mode:0o600});
 console.log('HTACCESS_STREAM_ALLOWLIST_PREPARED; public unchanged');
}else if(action==='apply'){
 const before=fs.readFileSync(beforePath),after=fs.readFileSync(afterPath);
 if(!fs.readFileSync(target).equals(before))throw Error('HTACCESS_CHANGED_EXTERNALLY; update stopped');
 if(!before.equals(after))atomic(after);
 console.log('HTACCESS_STREAM_API_ALLOWED; MODE=644');
}else if(action==='restore'){
 const before=fs.readFileSync(beforePath),after=fs.readFileSync(afterPath),now=fs.readFileSync(target);
 if(now.equals(before))console.log('HTACCESS_ORIGINAL_IN_PLACE; MODE=644');
 else if(now.equals(after)){atomic(before);console.log('HTACCESS_ROLLBACK_COMPLETE; MODE=644');}
 else throw Error('HTACCESS_CHANGED_EXTERNALLY; restore skipped to preserve newer settings');
}else if(action==='verify'){
 if(!fs.readFileSync(target).equals(fs.readFileSync(afterPath)))throw Error('HTACCESS_CHANGED_EXTERNALLY');
}else throw Error('Unknown action');
