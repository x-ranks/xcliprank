"use client";

import { useEffect } from "react";
import { trackEngagement } from "../../lib/engagement-client";

function rankingRange(sourcePage: string | null) {
  if (!sourcePage) return undefined;
  const path = sourcePage.split("?")[0];
  if (path === "/") return "trending";
  if (path === "/ranking/daily") return "daily";
  if (path === "/ranking/weekly") return "weekly";
  if (path === "/reels") return "reels";
  return undefined;
}

export default function PublicPostEngagement({ postId, sourcePage }: { postId: string; sourcePage: string | null }) {
  useEffect(() => {
    trackEngagement({
      eventType: "video_open",
      xPostId: postId,
      range: rankingRange(sourcePage),
      source: "post_detail",
    });
  }, [postId, sourcePage]);

  return null;
}
