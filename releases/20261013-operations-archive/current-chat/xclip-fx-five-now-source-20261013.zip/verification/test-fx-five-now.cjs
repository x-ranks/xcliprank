const fs=require('fs'),fsp=fs.promises,path=require('path'),os=require('os'),assert=require('assert/strict'),ts=require('C:/Projects/xcliprank/node_modules/typescript');
const w=__dirname,root=path.join(w,'fx-timeline-fix'),shell=fs.readFileSync(path.join(w,'../outputs/xclip-fx-five-now-20261013.sh'),'utf8');
const block=shell.split("<<'FX_FIVE_NOW_JS'\n")[1].split('\nFX_FIVE_NOW_JS')[0];
const encoded=block.match(/const encoded="([A-Za-z0-9+/=]+)"/)[1],bytes=Buffer.from(encoded,'base64'),source=bytes.toString('utf8');
const hash=require('crypto').createHash('sha256').update(bytes).digest('hex');assert(block.includes(hash));
const cache=new Map(),stubs={'lib/supabase-admin':{supabaseAdmin(){throw Error('REAL_DB_FORBIDDEN')}},'lib/free-curated-publish':{publishFreeCandidates(){throw Error('REAL_PUBLISH_FORBIDDEN')}},'lib/post-status-store':{unavailableKeys(){throw Error('REAL_STATE_FORBIDDEN')}}};
function load(id){if(stubs[id])return stubs[id];if(cache.has(id))return cache.get(id).exports;const m={exports:{}};cache.set(id,m);
 const text=id==='lib/fx-five-now'?source:fs.readFileSync(path.join(root,id+'.ts'),'utf8');
 const code=ts.transpileModule(text,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS,esModuleInterop:true}}).outputText;
 new Function('require','module','exports',code)(n=>n.startsWith('.')?load(path.posix.normalize(path.posix.join(path.posix.dirname(id),n))):require(n),m,m.exports);return m.exports;}
const scan=load('lib/free-curated-scan'),store=load('lib/free-curated-server-store'),xs=load('lib/x-curated-state'),fxs=load('lib/fx-curated-state');scan.importLegacyAuthors=async()=>{};
const run=load('lib/fx-five-now').verifyFxFiveNow,START=Date.UTC(2026,9,13,10),DAY=86400000,sid=t=>(((BigInt(t)-1288834974657n)<<22n)+1n).toString();
const author=i=>({...scan.newScheduledAuthor({id:String(1000+i),username:'mock'+i,name:'Mock',expectedTier:'S'},'free',START-DAY),latestId:sid(START-3600000),checkedAt:START-60000,nextCheckAt:START+DAY});
const dirs=[];
async function fixture(authors){const directory=await fsp.mkdtemp(path.join(os.tmpdir(),'xclip-five-now-'));dirs.push(directory);
 await store.writeScheduledFreeState({...store.freshFreeState(),authors,nextBatchAt:START+3*3600000},directory);
 const x=xs.freshXState();x.requests=7;x.rawPosts=12;x.reservations=Array.from({length:24},(_,i)=>({id:String(1000+i),at:START-60000}));await xs.writeXState(x,directory);
 const q=await fsp.readFile(path.join(directory,'x-api-v1.json')),calls=[],saved=[];
 const options={directory,now:()=>START,database:{from(){throw Error('REAL_DB_FORBIDDEN')}},pause:async()=>{},blocked:async()=>new Set(),
 fetcher:async(url,o)=>{assert.equal(new URL(url).origin,'https://api.fxtwitter.com');assert(!o.headers.Authorization);calls.push(url);
 const id=decodeURIComponent(new URL(url).pathname).match(/id:(\d+)/)[1];return Response.json({code:200,results:[{type:'status',provider:'twitter',id:sid(START-30000),author:{id,protected:false},text:'mock',created_timestamp:(START-30000)/1000,possibly_sensitive:false,media:{videos:[{type:'video',format:'video/mp4',url:'https://video.twimg.com/mock.mp4'}]}}]});},
 publish:async(a,p)=>{saved.push(...p.map(v=>v.x_post_id));return {saved:p.length,promoted:0}}};
 return {directory,q,calls,saved,options};}
(async()=>{try{
 // Full quota, existing reservations, author24h and scheduler3h all bypassed ONLY in this one-off module.
 const f=await fixture(Array.from({length:12},(_,i)=>author(i)));let r=await run(f.options);
 assert.equal(r.processed,5);assert.equal(r.failed,0);assert.equal(r.saved,5);assert.equal(r.verification.result,'PASSED');assert.equal(f.calls.length,5);
 assert.equal(new Set(r.verification.authors.map(a=>a.username)).size,5);assert.equal(r.normal_quota_changed,false);
 assert((await fsp.readFile(path.join(f.directory,'x-api-v1.json'))).equals(f.q));
 let s=await store.readScheduledFreeState(f.directory);assert.equal(s.nextBatchAt,START+3*3600000);assert(s.authors.every(a=>a.nextCheckAt>=START+DAY));
 let audit=JSON.parse(await fsp.readFile(path.join(f.directory,'fx-manual-five-now-20261013-v1.json'),'utf8'));assert.equal(audit.attempted,5);assert.equal(audit.completed,5);assert.equal(audit.result,'PASSED');
 await assert.rejects(run(f.options),/MANUAL_FIVE_ALREADY_STARTED/);assert.equal(f.calls.length,5);
 r=await scan.scanFreeCurated(f.options);assert.equal(r.skip_reason,'interval');assert.equal(f.calls.length,5);
 s=await store.readScheduledFreeState(f.directory);s.nextBatchAt=0;await store.writeScheduledFreeState(s,f.directory);
 r=await scan.scanFreeCurated(f.options);assert.equal(r.skip_reason,'daily_author_limit');assert.equal(f.calls.length,5);
 // Pause, initial import, manual block and real429 backoff remain authoritative even for immediate verification.
 const list=Array.from({length:9},(_,i)=>author(20+i));list[0].paused=true;list[1].initialPending=true;list[2].lastError='FxTwitter取得制限（HTTP 429）';
 const safe=await fixture(list);safe.options.blocked=async()=>new Set(['id:1023']);r=await run(safe.options);assert.equal(r.processed,5);
 assert(r.verification.authors.every(a=>!['mock20','mock21','mock22','mock23'].includes(a.username)));
 // Failure still counts one manual attempt, continues to the other four, and cannot be rerun automatically.
 const fail=await fixture(Array.from({length:5},(_,i)=>author(40+i)));fail.options.fetcher=async url=>{fail.calls.push(url);return new Response('',{status:429})};
 r=await run(fail.options);assert.equal(r.processed,5);assert.equal(r.failed,5);assert.equal(r.verification.result,'FAILED');
 assert((await fsp.readFile(path.join(fail.directory,'x-api-v1.json'))).equals(fail.q));
 audit=JSON.parse(await fsp.readFile(path.join(fail.directory,'fx-manual-five-now-20261013-v1.json'),'utf8'));assert.equal(audit.attempted,5);assert.equal(audit.result,'FAILED');
 await assert.rejects(run(fail.options),/ALREADY_STARTED/);assert.equal(fail.calls.length,5);
 // Too few safe authors: no partial sample, no marker consumption, no provider traffic.
 const few=await fixture([author(50),author(51)]);r=await run(few.options);assert.equal(r.processed,0);assert.equal(few.calls.length,0);
 assert(!fs.existsSync(path.join(few.directory,'fx-manual-five-now-20261013-v1.json')));
 // Shared operation.lock and corrupt-state guards precede marker/network access.
 const lock=await fixture(Array.from({length:5},(_,i)=>author(60+i)));await fsp.mkdir(path.join(lock.directory,'operation.lock'));
 await assert.rejects(run(lock.options),e=>e.status===409);assert.equal(lock.calls.length,0);
 const corrupt=await fixture(Array.from({length:5},(_,i)=>author(70+i)));await fsp.writeFile(path.join(corrupt.directory,'fx-patrol-v1.json'),'corrupt');
 await assert.rejects(run(corrupt.options),/STATE_INVALID/);assert.equal(corrupt.calls.length,0);
 // The one-off receipt must be durable before any request.
 const durable=await fixture(Array.from({length:5},(_,i)=>author(80+i))),write=fsp.writeFile;
 fsp.writeFile=async(file,...rest)=>{if(String(file).endsWith('fx-manual-five-now-20261013-v1.json'))throw Error('MOCK_RECEIPT_WRITE_FAILED');return write(file,...rest)};
 try{await assert.rejects(run(durable.options),/RECEIPT_WRITE_FAILED/);assert.equal(durable.calls.length,0);}finally{fsp.writeFile=write;}
 // Type check virtual source against the same actual source paths without writing app files.
 const config=ts.readConfigFile(path.join(root,'tsconfig.json'),ts.sys.readFile),parsed=ts.parseJsonConfigFileContent(config.config,ts.sys,root),filename=path.join(root,'lib/__fx_five_now_typecheck.ts');
 const opts={...parsed.options,noEmit:true,incremental:false},host=ts.createCompilerHost(opts),read=host.readFile.bind(host),exists=host.fileExists.bind(host),get=host.getSourceFile.bind(host);
 host.fileExists=p=>path.resolve(p)===filename||exists(p);host.readFile=p=>path.resolve(p)===filename?source:read(p);
 host.getSourceFile=(p,v,onError,newFile)=>path.resolve(p)===filename?ts.createSourceFile(p,source,v,true):get(p,v,onError,newFile);
 const program=ts.createProgram([filename,path.join(root,'next-env.d.ts')],opts,host),errors=ts.getPreEmitDiagnostics(program);
 assert.equal(errors.length,0,ts.formatDiagnosticsWithColorAndContext(errors,{getCanonicalFileName:x=>x,getCurrentDirectory:()=>root,getNewLine:()=> '\n'}));
 console.log('PASS IMMEDIATE FIVE: actual embedded runner; exact five at full24/future author and batch gates; quota bytes and nextBatch preserved; one durable sample/no re-execution; failure counts/continues; pause/import/removal/429/locks/corrupt-state/durability guards; source typecheck. All HTTP/DB mocked.');
}finally{for(const d of dirs){assert(path.dirname(d)===os.tmpdir()&&path.basename(d).startsWith('xclip-five-now-'));await fsp.rm(d,{recursive:true,force:true});}}})().catch(e=>{console.error(e);process.exitCode=1});
