import { cache } from "react";
import { productionPublicBackend } from "./public-video-production";
export const readPublicDetail = cache((id: string) => productionPublicBackend().service.detail(id));
export const readPublicAccount = cache((key: string, page = 1) => productionPublicBackend().service.account(key, page));
export const readPublicTag = cache((name: string, page = 1) => productionPublicBackend().service.tag(name, page));
export const readPublicLabels = cache(() => productionPublicBackend().service.activeLabels());
export const readPublicIndex = cache(() => productionPublicBackend().service.indexable());
