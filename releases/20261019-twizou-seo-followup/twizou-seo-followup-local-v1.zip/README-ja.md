# twizou SEO 追加実装・個別URL登録 ローカル同期

この配布物は **未適用** です。対象は `C:\Projects\xcliprank` の現在の構成です。38ファイルの変更前ハッシュを照合してから適用し、型検査・関連テストが失敗した場合は変更ファイルを自動復元します。ローカル開発サーバーを停止してから実行してください。

PowerShellでZIPを展開したフォルダーに移動し、次を実行します。

```powershell
node .\apply-local.cjs --check
node .\apply-local.cjs --apply
```

成功表示は `LOCAL_SYNC_APPLIED` です。`LOCAL_BACKUP=` と成功表示を共有してください。本番反映の後にローカル同期を行うと、`http://localhost:3000/manual-ranking` で個別URLを登録できます。操作には本番側で設定済みの `CRON_SECRET` を管理画面に入力します。通常の閲覧者には管理画面を公開しません。

直接再生できる HTTPS の mp4・webm・m3u8 などは動画として表示し、それ以外のURLは元ページへのリンクで表示します。新着・24時間・週間にそれぞれ指定順位を置けます。Xの投稿は既存の掲載条件を満たす場合だけ登録できます。

手動で戻す場合は、成功時に表示されたバックアップ先を使います。

```powershell
node .\apply-local.cjs --rollback "C:\Projects\xcliprank-local-backups\twizou-seo-followup-（成功時の名前）"
```

編集後のファイルが配布時と異なる場合、誤上書きを避けるためロールバックは停止します。
