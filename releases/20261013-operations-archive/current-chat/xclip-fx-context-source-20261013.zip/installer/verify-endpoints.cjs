const base=process.env.BASE,secret=process.env.CRON_SECRET;
if(!base||!(base==='https://xcliprank.com'||/^http:\/\/127\.0\.0\.1:\d+$/.test(base))||!secret)throw Error('CHECK_CONFIGURATION_MISSING');
const tag=base.startsWith('https:')?'PUBLIC_':'STAGING_';
async function request(p,options={}){return fetch(base+p,{...options,redirect:'manual',signal:AbortSignal.timeout(60000)});}
(async()=>{
 for(const p of ['/','/ranking/daily','/ranking/weekly','/reels','/download','/download-policy']){const r=await request(p);await r.body?.cancel();if(!r.ok)throw Error(tag+'PAGE_FAILED '+p+' HTTP='+r.status);console.log(tag+'PAGE_OK '+p);}
 const status=await request('/api/rankings?range=author-status'),state=await status.json();
 if(!status.ok||!state.ok||!Array.isArray(state.blockedKeys))throw Error(tag+'STATUS_FAILED');const blocked=new Set(state.blockedKeys);
 const unavailable=p=>blocked.has('post:'+p.x_post_id)||blocked.has(/^\d{2,20}$/.test(String(p.author_id??''))?'id:'+p.author_id:'name:'+String(p.author_username??'').toLowerCase());
 for(const range of ['trending','daily','weekly']){const r=await request('/api/rankings?range='+range),b=await r.json();if(!r.ok||!b.ok||!Array.isArray(b.data)||!b.data.length||b.data.some(unavailable))throw Error(tag+'RANKING_FAILED '+range);console.log(tag+'RANKING_OK '+range+' '+b.data.length);}
 const reels=await request('/api/reels'),rb=await reels.json();if(!reels.ok||!rb.ok||!Array.isArray(rb.data)||!rb.data.length||rb.data.some(unavailable))throw Error(tag+'REELS_FAILED');console.log(tag+'REELS_OK '+rb.data.length);
 const unauth=await request('/api/free-curated-sync');await unauth.body?.cancel();if(unauth.status!==401)throw Error(tag+'SYNC_AUTH_FAILED');
 const headers={authorization:'Bearer '+secret};const sync=await request('/api/free-curated-sync',{headers}),sb=await sync.json();
 if(!sync.ok||!sb.ok||sb.feature!=='free_curated_sync'||sb.provider!=='fxtwitter'||sb.scheduledProvider!=='fxtwitter'||sb.dailyAuthorLimit!==24||sb.commonManagement!==true||sb.availabilityDashboard!==true||sb.paid_x_requests!==0)throw Error(tag+'SYNC_ROUTE_FAILED_HTTP_'+sync.status);
 const read=await request('/api/free-curated-sync',{method:'POST',headers:{...headers,'content-type':'application/json'},body:JSON.stringify({action:'status',databaseHost:process.env.SUPABASE_URL?new URL(process.env.SUPABASE_URL).hostname:new URL(process.env.NEXT_PUBLIC_SUPABASE_URL).hostname})});
 const data=await read.json();if(!read.ok||!data.ok||!Array.isArray(data.state?.authors)||data.paid_x_requests!==0)throw Error(tag+'SYNC_POST_OR_STATE_FAILED_HTTP_'+read.status);
 const dash=await request('/api/free-curated-sync',{method:'POST',headers:{...headers,'content-type':'application/json'},body:JSON.stringify({action:'dashboard',databaseHost:process.env.SUPABASE_URL?new URL(process.env.SUPABASE_URL).hostname:new URL(process.env.NEXT_PUBLIC_SUPABASE_URL).hostname})});
 const db=await dash.json();if(!dash.ok||!db.ok||db.dashboard?.feature!=='free_curated_dashboard'||!Array.isArray(db.dashboard.authors)||db.dashboard.provider!=='fxtwitter'||db.dashboard.errorPolicy!=='continue_next_author'||db.dashboard.collectorCooldownUntil!==0||db.dashboard.dailyAuthorLimit!==24||db.paid_x_requests!==0)throw Error(tag+'DASHBOARD_FAILED_HTTP_'+dash.status);
 console.log(tag+'FREE_CURATED_DASHBOARD_OK; read-only state/DB; no provider requests');
 for(const body of [{action:'manage',operation:'list'},{action:'availability'}]){const r=await request('/api/free-curated-sync',{method:'POST',headers:{...headers,'content-type':'application/json'},body:JSON.stringify({...body,databaseHost:process.env.SUPABASE_URL?new URL(process.env.SUPABASE_URL).hostname:new URL(process.env.NEXT_PUBLIC_SUPABASE_URL).hostname})}),b=await r.json();if(!r.ok||!b.ok||(body.action==='manage'?!Array.isArray(b.authors):!b.availability?.counts))throw Error(tag+'COMMON_MANAGEMENT_OR_AVAILABILITY_FAILED');}console.log(tag+'COMMON_MANAGEMENT_AND_AVAILABILITY_OK; read only; no provider requests');
 for(const p of ['/curated-manager','/availability-monitor']){const r=await request(p);await r.body?.cancel();if(r.status!==404)throw Error(tag+'LOCAL_ADMIN_EXPOSED');}
 const old=await request('/api/collect-curated-batch',{headers}),ob=await old.json();if(!old.ok||ob.provider!=='fxtwitter'||ob.scheduledBy!=='server_cron'||ob.paid_x_requests!==0)throw Error(tag+'OLD_PAID_CRON_NOT_DISABLED');
 const local=await request('/fxtwitter-authors');await local.body?.cancel();if(local.status!==404)throw Error(tag+'LOCAL_ADMIN_EXPOSED');
 console.log(tag+'FREE_CURATED_SYNC_OK; legacy scheduled paid requests disabled; no external provider/CDN requests');
})().catch(e=>{console.error(e.message);process.exitCode=1;});
