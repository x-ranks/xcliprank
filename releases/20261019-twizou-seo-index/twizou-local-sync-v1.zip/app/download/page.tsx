import type { Metadata } from "next";
import DownloadForm from "./DownloadForm";
import Link from "next/link";
import { SITE_NAME, SITE_URL } from "../../lib/seo";

export const metadata: Metadata = {
  title: { absolute: `X動画保存｜投稿URLから端末に保存｜${SITE_NAME}` },
  description: "X・Twitterの公開投稿URLから、保存を許可された動画を端末に保存できます。保存ポリシーを確認してご利用ください。",
  alternates: { canonical: "/download" },
  openGraph: { type: "website", title: `X動画保存｜${SITE_NAME}`, description: "保存を許可されたX動画を投稿URLから端末に保存できます。", url: `${SITE_URL}/download`, images: [`${SITE_URL}/twizou-share.png`] },
  twitter: { card: "summary_large_image", title: `X動画保存｜${SITE_NAME}`, description: "保存を許可されたX動画を投稿URLから端末に保存できます。", images: [`${SITE_URL}/twizou-share.png`] },
};
export default function DownloadPage() { return <><DownloadForm /><section style={{ maxWidth: 860, margin: "32px auto", padding: "0 18px" }}>
  <h2>投稿URLから動画を保存する方法</h2>
  <p>公開されているXの投稿URLを入力し、当サイトの保存条件に合う動画か確認してください。条件を満たす場合、動画はXの配信元からお使いの端末に直接読み込まれます。</p>
  <p>動画ファイルを当サイトに保管・再アップロードする仕組みではありません。保存できる範囲と注意点は<Link href="/download-policy">保存ポリシー</Link>をご確認ください。</p>
</section></>; }
