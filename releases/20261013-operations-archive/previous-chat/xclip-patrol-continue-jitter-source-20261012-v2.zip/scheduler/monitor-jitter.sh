#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
ACCOUNT=/home/rbxfxmfd
NODE="$ACCOUNT/.local/node/node-v22.23.2-linux-x64/bin/node"
export PATH="$(dirname "$NODE"):$PATH"
[[ "$#" -le 1 && ( "${1:-}" == "" || "${1:-}" == "--check-runtime" ) ]] || { echo 'AUTHOR_MONITOR_INVALID_ARGUMENT'; exit 2; }
if ! LOCATIONS_TEXT=$(ACCOUNT="$ACCOUNT" "$NODE" <<'JS'
const fs=require('fs'),path=require('path'),a=process.env.ACCOUNT;
const ht=fs.readFileSync(path.join(a,'public_html/.htaccess'),'utf8');
const roots=[...ht.matchAll(/^\s*PassengerAppRoot\s+"([^"]+)"\s*$/gm)];
if(roots.length!==1||!/^\/home\/rbxfxmfd\/xclip-[^\r\n]+\/runtime$/.test(roots[0][1]))throw Error('UNEXPECTED_RUNTIME');
const runtime=roots[0][1],source=fs.readFileSync(path.join(runtime,'DEPLOY_SOURCE'),'utf8').trim();
if(!/^\/home\/rbxfxmfd\/xclip-[^\r\n]+\/source$/.test(source)||
 fs.readFileSync(path.join(source,'.next/BUILD_ID'),'utf8').trim()!==fs.readFileSync(path.join(runtime,'.next/BUILD_ID'),'utf8').trim())throw Error('MONITOR_SOURCE_MISMATCH');
console.log(runtime);console.log(source);
JS
); then
 echo 'AUTHOR_MONITOR_RUNTIME_LOOKUP_FAILED; no scan started'
 exit 1
fi
readarray -t LOCATIONS <<< "$LOCATIONS_TEXT"
unset LOCATIONS_TEXT
[[ "${#LOCATIONS[@]}" == 2 ]] || { echo 'AUTHOR_MONITOR_RUNTIME_NOT_FOUND'; exit 1; }
RUNTIME="${LOCATIONS[0]}"
SOURCE="${LOCATIONS[1]}"
[[ -f "$SOURCE/scripts/scan-author-status.cjs" ]] || { echo 'AUTHOR_MONITOR_NOT_SUPPORTED_BY_RUNTIME'; exit 1; }
if [[ "${1:-}" == "--check-runtime" ]]; then
 echo 'AUTHOR_MONITOR_RUNTIME_CHECK_OK; no API requests'
 exit 0
fi
# The existing script owns its original lock, logging and worker invocation.
# Keep it untouched; check-runtime above never executes the existing script.
JITTER_SECONDS=$(ACCOUNT="$ACCOUNT" "$NODE" <<'JS'
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const p=path.join(process.env.ACCOUNT,'xclip-author-monitor.sh'),s=fs.lstatSync(p);
if(!s.isFile()||s.uid!==process.getuid())throw Error('LEGACY_MONITOR_UNSAFE');
const digest=crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
// A successfully installed v1 monitor already has start jitter. Do not add a second delay.
console.log(digest==='a2d12973ddcd5ecdbeb02f793e1c6b9edb2159ee7e545fc0849ebd6077bac7b6'?0:crypto.randomInt(0,241));
JS
)
[[ "$JITTER_SECONDS" =~ ^[0-9]+$ && "$JITTER_SECONDS" -le 240 ]] || { echo 'AUTHOR_MONITOR_INVALID_JITTER'; exit 1; }
sleep "$JITTER_SECONDS"
exec /bin/bash "$ACCOUNT/xclip-author-monitor.sh"
