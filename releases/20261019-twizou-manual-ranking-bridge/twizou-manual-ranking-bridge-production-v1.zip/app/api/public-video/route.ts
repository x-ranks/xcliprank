import { productionPublicBackend } from "../../../lib/public-video-production";
import type { NextRequest } from "next/server";
import { GET as readManualRanking } from "../manual-ranking/route";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const headers = { "Cache-Control": "no-store", "X-Robots-Tag": "noindex, nofollow, noarchive" };
export async function GET(request: NextRequest) {
  const url = new URL(request.url), type = url.searchParams.get("type"), value = url.searchParams.get("value") ?? "";
  if (type === "placement") return readManualRanking(request);
  const rawPage = url.searchParams.get("page"), page = rawPage === null ? 1 : Number(rawPage);
  if (value.length > 160 || !Number.isInteger(page) || page < 1 || page > 9999) return Response.json({ ok: false }, { status: 400, headers });
  try {
    const s = productionPublicBackend().service;
    const data = type === "detail" ? await s.detail(value) : type === "account" ? await s.account(value, page) : type === "tag" ? await s.tag(value, page) : type === "labels" ? await s.activeLabels() : type === "sitemap" ? await s.indexable() : undefined;
    return data === undefined ? Response.json({ ok: false }, { status: 400, headers }) : Response.json({ ok: true, data }, { headers });
  } catch { return Response.json({ ok: false, error: "PUBLIC_READ_UNAVAILABLE" }, { status: 503, headers }); }
}
