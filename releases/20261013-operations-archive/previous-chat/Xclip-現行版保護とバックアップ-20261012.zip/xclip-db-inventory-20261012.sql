-- Read-only inventory for Supabase SQL Editor. No rows, flags or cursors are modified.
BEGIN READ ONLY;
SELECT version();
SELECT table_schema,table_name FROM information_schema.tables
 WHERE table_type='BASE TABLE' AND table_schema NOT IN ('pg_catalog','information_schema')
 ORDER BY table_schema,table_name;
SELECT extname,extversion FROM pg_extension ORDER BY extname;
SELECT schemaname,tablename,rowsecurity FROM pg_tables WHERE schemaname='public' ORDER BY tablename;
SELECT count(*) AS posts_count FROM public.posts;
SELECT count(*) AS authors_count FROM public.authors;
COMMIT;
