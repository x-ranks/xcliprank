const fs=require('fs'),path=require('path'),assert=require('assert/strict'),realModule=require('module');
const w=__dirname,base=JSON.parse(fs.readFileSync(path.join(w,'fx-timeline-shipped/payload.json'),'utf8'));
const shell=fs.readFileSync(path.join(w,'../outputs/xclip-fx-five-now-20261013.sh'),'utf8');
const block=shell.split("<<'FX_FIVE_NOW_JS'\n")[1].split('\nFX_FIVE_NOW_JS')[0];
const fixture=fs.mkdtempSync(path.join(w,'five-now-loader-check-'));
(async()=>{try{
 for(const[n,t]of Object.entries(base.files)){const f=path.join(fixture,n);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,t);}
 fs.writeFileSync(path.join(fixture,'package.json'),'{}');fs.symlinkSync('C:/Projects/xcliprank/node_modules',path.join(fixture,'node_modules'),'junction');
 async function evaluate(){const output=[],processMock={cwd:()=>fixture,exitCode:undefined};let compiled=0,called=0;
  class MockModule{constructor(){this.exports={}} _compile(code,filename){compiled++;assert(filename.endsWith('__fx_five_now_virtual_20261013.cjs'));assert(code.includes('verifyFxFiveNow'));this.exports={verifyFxFiveNow:async()=>{called++;return {verification:{result:'PASSED'},processed:5}}};}}
  MockModule._nodeModulePaths=realModule.Module._nodeModulePaths;
  function req(n){return n==='node:module'?{createRequire:realModule.createRequire,Module:MockModule}:require(n);}req.extensions={};
  new Function('require','process','console',block)(req,processMock,{log:x=>output.push(String(x)),error:x=>output.push(String(x))});
  for(let i=0;i<4;i++)await new Promise(r=>setImmediate(r));return {output,compiled,called,code:processMock.exitCode};
 }
 let r=await evaluate();assert.equal(r.compiled,1);assert.equal(r.called,1);assert(r.output.includes('XCLIP_FX_FIVE_NOW_PASSED'));
 fs.appendFileSync(path.join(fixture,'lib/free-curated-publish.ts'),'\n// unknown edit');
 r=await evaluate();assert.equal(r.compiled,0);assert.equal(r.called,0);assert.equal(r.code,1);assert(r.output.some(x=>x.includes('SOURCE_MISMATCH')));
 assert(!shell.includes('sleep 900'));assert(shell.includes('.xclip-free-curated-collector.lock'));assert(shell.includes('flock -n 9'));assert(shell.includes('[[ "$#" == 0 ]]'));
 console.log('PASS IMMEDIATE LOADER: actual downloadable block/hash guards/in-memory module wiring; unknown shared publisher refused before execution; same flock; no wait/background or app source writes. HTTP/DB entry mocked.');
}finally{
 const junction=path.join(fixture,'node_modules');if(fs.existsSync(junction))fs.rmdirSync(junction);
 assert(path.dirname(fixture)===w&&path.basename(fixture).startsWith('five-now-loader-check-'));fs.rmSync(fixture,{recursive:true,force:true});
}})().catch(e=>{console.error(e);process.exitCode=1});
