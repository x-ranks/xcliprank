import { readPublicIndex } from "../lib/public-video-server";
export const dynamic = "force-dynamic";
import type { MetadataRoute } from "next";
import { SITE_URL } from "../lib/seo";
import { browsePageCount, browseHref, accountPageCount, accountListHref } from "../lib/public-list-pages";
import { isIndexable } from "../lib/indexability";
import { tagHref } from "../lib/public-video-core";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  // Fail visibly on a database error; an empty sitemap would falsely signal removals.
  const index = await readPublicIndex();
  return [
    { url: SITE_URL },
    { url: `${SITE_URL}/ranking/daily` },
    { url: `${SITE_URL}/ranking/weekly` },
    { url: `${SITE_URL}/download` },
    ...(isIndexable({ type: "tag-hub", activeTags: index.tags.length }) ? [{ url: `${SITE_URL}/tags` }] : []),
    ...Array.from({ length: browsePageCount(index.posts.length) }, (_, i) => ({ url: SITE_URL + browseHref(i + 1) })),
    ...Array.from({ length: accountPageCount(index.accounts.length) }, (_, i) => ({ url: SITE_URL + accountListHref(i + 1) })),
    ...index.posts.map(p => ({ url: `${SITE_URL}/p/${p.id}`, ...(p.modifiedAt ? { lastModified: p.modifiedAt } : {}) })),
    ...index.accounts.map(a => ({ url: `${SITE_URL}/accounts/${encodeURIComponent(a.key)}`, ...(a.modifiedAt ? { lastModified: a.modifiedAt } : {}) }))
    ,...index.tags.filter(tag => tag.index).map(tag => ({ url: SITE_URL + tagHref({ ...tag, active: true }) }))
  ];
}
