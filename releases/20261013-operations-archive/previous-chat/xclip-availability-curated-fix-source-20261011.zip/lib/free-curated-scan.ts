import { newFreeMetrics } from "./free-curated-metrics";
import { supabaseAdmin } from "./supabase-admin";
import { fetchFreeProfile, fetchFreeMediaPage, FreeCuratedError, type FreeAuthor } from "./fxtwitter-curated";
import { publishFreeCandidates } from "./free-curated-publish";
import { withScheduledFreeState, writeScheduledFreeState, type ScheduledFreeAuthor, type ScheduledFreeState } from "./free-curated-server-store";
import { readAuthorState } from "./author-status-store";
import { readPostState } from "./post-status-store";

const HOUR = 3600000, DAY = 24 * HOUR;
export const FREE_COLLECTION_INTERVAL = 3 * HOUR, FREE_COLLECTION_BATCH = 8, FREE_COLLECTION_SPACING = 5000;
const maxId = (ids: (string | null)[]) => ids.filter((s): s is string => !!s).reduce<string | null>((a,b) => !a || BigInt(b) > BigInt(a) ? b : a,null);
export function newScheduledAuthor(a: FreeAuthor, source: "legacy" | "free", now: number): ScheduledFreeAuthor {
  return {...a,source,paused:false,addedAt:now,checkedAt:0,nextCheckAt:0,latestId:null,pendingCursor:null,
    pendingLatestId:null,baselineId:null,savedTotal:0,lastError:null};
}
export async function importLegacyAuthors(state: ScheduledFreeState, database = supabaseAdmin(), now = Date.now()) {
  const {data,error} = await database.from("authors").select("x_author_id,username,name,curated_expected_tier,curated_status,curated_backfill_status,curated_last_post_id")
    .eq("is_curated",true).limit(1000);
  if (error || !Array.isArray(data)) throw new FreeCuratedError(503,"従来投稿者のDB確認に失敗しました。無料巡回を停止しました。");
  const legacy = new Map<string, any>(data.map(a=>[String(a.x_author_id),a]));
  for (const a of state.authors.filter(a=>a.source === "legacy")) {
    const row=legacy.get(a.id); a.paused=!row || row.curated_status !== "active";
  }
  for (const row of data) {
    const id=String(row.x_author_id), username=String(row.username??"");
    if (row.curated_status !== "active" || !/^\d{2,20}$/.test(id) || !/^[a-z0-9_]{1,15}$/i.test(username) || state.authors.some(a=>a.id===id)) continue;
    if (state.authors.length>=100) throw new FreeCuratedError(409,"無料巡回の投稿者数が100件を超えます。登録数を確認してください。");
    const added=newScheduledAuthor({id,username,name:String(row.name??username).slice(0,256),expectedTier:row.curated_expected_tier === "A" ? "A":"S"},"legacy",now);
    if(/^\d{2,20}$/.test(String(row.curated_last_post_id??"")))added.latestId=String(row.curated_last_post_id);
    state.authors.push(added);
  }
}
export async function scanFreeCurated(options: {
  directory?: string; database?: ReturnType<typeof supabaseAdmin>; now?:()=>number; fetcher?:typeof fetch;
  pause?:()=>Promise<void>; publish?:typeof publishFreeCandidates; availabilityCooldown?:()=>Promise<number>;
} = {}) {
  const now=options.now??Date.now;
  return withScheduledFreeState(async state=>{
    const stats={feature:"free_curated_collection",skipped:false,processed:0,saved:0,failed:0,pending:0,stopped:false,
      registered:state.authors.length,paid_x_requests:0,next_batch_at:state.nextBatchAt,waiting_until:0,skip_reason:null as string|null,fetched:0,new_posts:0,empty:0};
    state.lastRun={at:now(),finishedAt:0,outcome:"running",reason:null,processed:0,fetched:0,saved:0,failed:0,empty:0};
    const finish=async(outcome:"completed"|"skipped"|"paused"|"error",reason:string|null=null)=>{
      Object.assign(state.lastRun!,{finishedAt:now(),outcome,reason,processed:stats.processed,fetched:stats.fetched,saved:stats.saved,failed:stats.failed,empty:stats.empty});
      await writeScheduledFreeState(state,options.directory);
    };
    try {
    if (Math.max(state.nextBatchAt,state.cooldownUntil)>now()) {stats.skipped=true;stats.skip_reason=state.cooldownUntil>now()?"collector_cooldown":"interval";stats.waiting_until=Math.max(state.nextBatchAt,state.cooldownUntil);await finish("skipped",stats.skip_reason);return stats;}
    const externalCooldown=options.availabilityCooldown?await options.availabilityCooldown():Math.max((await readAuthorState()).cooldownUntil,(await readPostState()).cooldownUntil);
    if(externalCooldown>now()){stats.skipped=true;stats.skip_reason="availability_cooldown";stats.waiting_until=externalCooldown;await finish("skipped",stats.skip_reason);return stats;}
    // Reserve before DB/network work, so repeated hourly calls cannot multiply external requests.
    state.nextBatchAt=now()+FREE_COLLECTION_INTERVAL-5*60000;
    await writeScheduledFreeState(state,options.directory);stats.next_batch_at=state.nextBatchAt;
    const db=options.database??supabaseAdmin();
    await importLegacyAuthors(state,db,now()); await writeScheduledFreeState(state,options.directory);
    stats.registered=state.authors.length;
    const due=state.authors.filter(a=>!a.paused&&a.nextCheckAt<=now())
      .sort((a,b)=>a.checkedAt-b.checkedAt||a.id.localeCompare(b.id)).slice(0,FREE_COLLECTION_BATCH);
    const pause=options.pause??(()=>new Promise<void>(r=>setTimeout(r,FREE_COLLECTION_SPACING)));
    const fetcher:typeof fetch=async(...args)=>{await pause();return (options.fetcher??fetch)(...args);};
    let failures=0;
    for(const author of due){
      const startedAt=now();author.checkedAt=startedAt;author.nextCheckAt=startedAt+DAY;
      const metrics=author.metrics??newFreeMetrics(startedAt);author.metrics=metrics;
      metrics.lastOutcome="running";metrics.lastFetched=null;metrics.lastNew=null;metrics.lastSaved=null;metrics.lastDurationMs=null;
      await writeScheduledFreeState(state,options.directory);
      try{
        const profile=await fetchFreeProfile(`id:${author.id}`,author.expectedTier,fetcher);
        const page=await fetchFreeMediaPage(profile,100,author.pendingCursor,fetcher);
        if(page.rawCount===0&&(!author.pendingCursor||page.nextCursor)) {
          metrics.lastOutcome="empty";stats.empty++;
          throw new FreeCuratedError(502,"FxTwitterの投稿一覧が空です。取得成功とは判断せず、投稿IDと掲載済み動画を保持します。");
        }
        metrics.lastFetched=page.posts.length;metrics.fetchedTotal+=page.posts.length;stats.fetched+=page.posts.length;
        if(author.pendingCursor&&page.nextCursor===author.pendingCursor)throw new FreeCuratedError(502,"ページ送りが進みません。");
        if(page.rawCount>0&&!page.timelineIds.length)throw new FreeCuratedError(502,"投稿一覧の同一投稿者を確認できません。");
        const boundary=author.pendingCursor?author.baselineId:author.latestId;
        const posts=page.posts.filter(p=>!boundary||BigInt(p.x_post_id)>BigInt(boundary));
        metrics.lastNew=posts.length;metrics.newTotal+=posts.length;stats.new_posts+=posts.length;
        const latest=maxId([author.pendingLatestId,...page.timelineIds]);
        const caughtUp=!boundary || !page.nextCursor || page.timelineIds.includes(boundary) ||
          (page.timelineIds.length>0 && page.timelineIds.every(id=>BigInt(id)<=BigInt(boundary)));
        const published=await (options.publish??publishFreeCandidates)(profile,posts,{database:db});
        author.username=profile.username;author.name=profile.name;author.savedTotal+=published.saved;author.lastError=null;
        metrics.lastSaved=published.saved;metrics.lastSuccessAt=now();metrics.successCount++;metrics.consecutiveFailures=0;
        metrics.lastOutcome=posts.length?"success":"no_new";
        if(posts.length>0)metrics.recentVideos=posts.slice(0,10).map(p=>({id:p.x_post_id,at:p.created_at,url:p.x_url}));
        if(caughtUp){author.latestId=maxId([author.latestId,latest]);author.pendingCursor=null;author.pendingLatestId=null;author.baselineId=null;}
        else{author.pendingCursor=page.nextCursor;author.pendingLatestId=latest;author.baselineId=boundary;stats.pending++;}
        stats.saved+=published.saved;failures=0;
      }catch(error){
        stats.failed++;
        failures = error instanceof FreeCuratedError && error.providerFailure ? failures + 1 : 0;
        metrics.failureCount++;metrics.consecutiveFailures++;
        if(metrics.lastOutcome!=="empty")metrics.lastOutcome="error";
        author.lastError=error instanceof FreeCuratedError?error.message.slice(0,256):"無料収集・DB保存に失敗しました。";
        if(error instanceof FreeCuratedError&&error.status===429 || failures>=2){
          state.cooldownUntil=now()+Math.max(6*HOUR,error instanceof FreeCuratedError?error.retryAfterMs??0:0);stats.stopped=true;
        }
      }
      metrics.lastDurationMs=Math.max(0,now()-startedAt);
      stats.processed++;await writeScheduledFreeState(state,options.directory);
      if(stats.stopped)break;
    }
    await finish(stats.stopped?"paused":"completed");return stats;
    } catch(e) {await finish("error","collection_or_state_failure");throw e;}
  },options.directory);
}
