# twizou 個別URLランキング登録・本番API経路修正

既存の `/api/manual-ranking` が公開側で403 HTMLになるため、管理画面専用の読み取りを `GET /api/public-video?type=placement`、登録を `POST /api/engagement?type=placement` に接続します。両経路とも既存の管理キー認証を必須とし、通常の閲覧・操作記録処理は維持します。

適用対象は、SEO followup v1 が適用された本番ソースです。先に `--check` でソースと配布物のハッシュ、稼働中の監視処理を照合します。照合に失敗したら適用しません。

```bash
mkdir -p /home/rbxfxmfd/twizou-manual-ranking-bridge-v1-20261019
unzip -q /home/rbxfxmfd/twizou-manual-ranking-bridge-production-v1.zip -d /home/rbxfxmfd/twizou-manual-ranking-bridge-v1-20261019
bash /home/rbxfxmfd/twizou-manual-ranking-bridge-v1-20261019/apply-production.sh --check
bash /home/rbxfxmfd/twizou-manual-ranking-bridge-v1-20261019/apply-production.sh --apply
```

`--apply` は検証用ディレクトリでテスト、型検査、ビルドを実行してから本番ランタイムを切り替えます。公開経路の認証確認に失敗した場合、前のランタイムへ自動復元します。失敗表示が出た場合は再実行せず、出力を共有してください。

成功表示は `MANUAL_RANKING_BRIDGE_AUTH_CHECK_OK`、`PREVIOUS_RUNTIME_BACKUP=...`、`NEW_BUILD_ID=...`、`TWIZOU_MANUAL_RANKING_BRIDGE_V1_DEPLOYMENT_COMPLETE` です。続けてローカル用パッケージを適用し、管理画面の状態読み込み・登録を確認してください。管理キーは共有しないでください。
