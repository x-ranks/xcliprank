param([switch]$Apply)
$ErrorActionPreference = 'Stop'
$project = 'C:\Projects\xcliprank'
$relative = 'scripts\test-public-pages.cjs'
$target = Join-Path $project $relative
$source = Join-Path $PSScriptRoot $relative
$before = '1952C35EF40527DD1CB27023B068DF5E4C5F3EC6F5A22061B54EFB49D166527A'
$after = '9B141424409343E63210940E63CC88EA649E27771864FD39B5A8B7BC58AC8A14'
if (-not (Test-Path -LiteralPath $target) -or -not (Test-Path -LiteralPath $source)) { throw 'EXPECTED_TEST_FILE_MISSING' }
if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $after) { throw 'PAYLOAD_HASH_MISMATCH' }
$actual = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
if ($actual -eq $after) { Write-Output 'LOCAL_TEST_FIX_ALREADY_APPLIED'; exit 0 }
if ($actual -ne $before) { throw 'LOCAL_TEST_BASELINE_CHANGED; no changes' }
Write-Output 'LOCAL_TEST_FIX_PRECHECK_OK; no changes'
if (-not $Apply) { exit 0 }
$backup = Join-Path 'C:\Projects\xcliprank-local-backups' ('twizou-engagement-open-test-fix-' + (Get-Date -Format 'yyyyMMddTHHmmssfff'))
New-Item -ItemType Directory -Force -Path $backup | Out-Null
Copy-Item -LiteralPath $target -Destination (Join-Path $backup 'test-public-pages.cjs')
Write-Output "LOCAL_BACKUP=$backup"
try {
  Copy-Item -LiteralPath $source -Destination $target
  Push-Location $project
  try {
    & node $relative
    if ($LASTEXITCODE -ne 0) { throw 'LOCAL_PUBLIC_PAGES_TEST_FAILED' }
  } finally { Pop-Location }
  if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $after) { throw 'LOCAL_COPY_HASH_MISMATCH' }
  Write-Output "LOCAL_TEST_FIX_APPLIED files=1 backup=$backup"
} catch {
  Copy-Item -LiteralPath (Join-Path $backup 'test-public-pages.cjs') -Destination $target -Force
  Write-Output 'LOCAL_TEST_FIX_FAILED_PREVIOUS_FILE_RESTORED'
  throw
}
