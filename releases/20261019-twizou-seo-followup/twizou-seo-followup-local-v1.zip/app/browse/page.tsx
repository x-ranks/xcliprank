import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { readPublicIndex } from "../../lib/public-video-server";
import { SITE_URL } from "../../lib/seo";
import { browsePageCount, browseHref } from "../../lib/public-list-pages";
export const dynamic = "force-dynamic";
const PAGE_SIZE = 100;
type Props = { searchParams: Promise<{ page?: string | string[] }> };
function pageNumber(value: string | string[] | undefined) {
  if (value === undefined) return 1;
  if (typeof value !== "string" || !/^[1-9]\d{0,3}$/.test(value)) notFound();
  return Number(value);
}
export async function generateMetadata({ searchParams }: Props): Promise<Metadata> {
  const page = pageNumber((await searchParams).page);
  const canonical = SITE_URL + browseHref(page);
  return { title: `動画一覧 ${page}ページ`, description: "twizouに掲載中の動画を全件たどれる一覧です。", alternates: { canonical },
    robots: { index: true, follow: true }, openGraph: { title: `動画一覧 ${page}ページ｜twizou`, url: canonical } };
}
export default async function BrowsePage({ searchParams }: Props) {
  const page = pageNumber((await searchParams).page), index = await readPublicIndex();
  const pages = browsePageCount(index.posts.length);
  if (page > pages) notFound();
  const posts = index.posts.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  return <main style={{ maxWidth: 1000, margin: "0 auto", padding: 24 }}>
    <Link href="/">新着ランキング</Link> ／ <Link href="/accounts">投稿者一覧</Link>
    <h1>動画一覧</h1><p>掲載条件を満たす動画を投稿ID順に掲載しています。全{index.posts.length}件。</p>
    <nav aria-label="動画一覧のページ" style={{ display: "flex", flexWrap: "wrap", gap: 12 }}>
      {Array.from({ length: pages }, (_, i) => <Link key={i} href={browseHref(i + 1)} aria-current={page === i + 1 ? "page" : undefined}>{i + 1}</Link>)}
    </nav>
    <ol start={(page - 1) * PAGE_SIZE + 1} style={{ display: "grid", gap: 8, overflowWrap: "anywhere" }}>
      {posts.map(post => <li key={post.id}><Link href={`/p/${post.id}`}>動画 {post.id}</Link></li>)}
    </ol>
  </main>;
}
