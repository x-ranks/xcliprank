const fs=require('fs'),path=require('path'),assert=require('assert/strict'),ts=require('typescript');
const root=path.resolve(__dirname,'..'),m={exports:{}};
const code=ts.transpileModule(fs.readFileSync(path.join(root,'lib/fxtwitter-curated.ts'),'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText;
new Function('require','module','exports',code)(require,m,m.exports);
const {parseFreeMediaPage,fetchFreeMediaPage}=m.exports,author={id:'12345',username:'fixture',name:'Fixture',expectedTier:'S'};
const post=id=>({type:'status',provider:'twitter',id,author:{id:author.id,protected:false},text:'mock',created_timestamp:Math.floor(Date.now()/1000)-60,possibly_sensitive:false,
 media:{videos:[{type:'video',format:'video/mp4',url:'https://video.twimg.com/mock.mp4'}]}});
const parse=results=>parseFreeMediaPage({code:200,results},author,true);
(async()=>{
 const own=post('30001'),rp={...post('40001'),author:{id:'99999',protected:false},reposted_by:{id:author.id}};
 let p=parse([own,own,rp]);assert.equal(p.timeline.trusted,true);assert.deepEqual(p.timeline.ids,['30001']);assert.equal(p.posts.length,1);assert.equal(p.timeline.counts.duplicates,1);assert.equal(p.timeline.counts.reposts,1);
 p=parse([rp]);assert.equal(p.timeline.trusted,true);assert.deepEqual(p.timeline.ids,[]);assert.equal(p.posts.length,0);
 for(const [bad,count]of [[{...own,type:undefined},'type'],[{...own,provider:undefined},'provider'],[{...own,id:30001},'id'],[{...own,author:undefined},'author'],[{...own,author:{id:'99999'}},'foreign'],[{...rp,reposted_by:{id:'99999'}},'repostIdentity'],[{...own,text:'conflicting'},'conflict']]){
  p=parse([own,bad]);assert.equal(p.timeline.trusted,false,count);assert.equal(p.timeline.counts[count],1,count);
 }
 const reply={...own,replying_to:{screen_name:'someone',status:'20001'}};
 assert.equal(parseFreeMediaPage({code:200,results:[reply]},author).posts.length,0);assert.equal(parse([reply]).posts.length,1);
 const calls=[];const fetcher=async url=>{calls.push(new URL(url));return Response.json({code:200,results:[own],cursor:{bottom:null}})};
 await fetchFreeMediaPage(author,100,null,fetcher,undefined,100,true);assert.equal(calls.at(-1).searchParams.get('with_replies'),'1');
 await fetchFreeMediaPage(author,100,null,fetcher);assert.equal(calls.at(-1).searchParams.has('with_replies'),false);
 await fetchFreeMediaPage(author,100,'OLD_MEDIA_CURSOR',fetcher,undefined,100,true);assert(calls.at(-1).pathname.endsWith('/media'));assert.equal(calls.at(-1).searchParams.has('with_replies'),false);
 const continuation=async url=>{calls.push(new URL(url));return Response.json({code:200,results:[own],cursor:{bottom:'NEXT'}})};
 let next=await fetchFreeMediaPage(author,100,null,continuation,undefined,100,true);assert.equal(next.nextCursor,'xclip-statuses-replies-v1:NEXT');
 next=await fetchFreeMediaPage(author,100,next.nextCursor,continuation,undefined,100,true);assert.equal(calls.at(-1).searchParams.get('cursor'),'NEXT');assert.equal(calls.at(-1).searchParams.get('with_replies'),'1');
 next=await fetchFreeMediaPage(author,100,'xclip-statuses-v1:OLD_NEXT',continuation,undefined,100,true);assert.equal(calls.at(-1).searchParams.get('cursor'),'OLD_NEXT');assert.equal(calls.at(-1).searchParams.has('with_replies'),false);assert.equal(next.nextCursor,'xclip-statuses-v1:NEXT');
 console.log('PASS TIMELINE: attributed reposts and identical pinned duplicates; foreign/malformed/conflicting rows refused; fixed request host; own reply opt-in; legacy bulk/media behavior retained. All HTTP mocked.');
})().catch(e=>{console.error(e);process.exitCode=1});
